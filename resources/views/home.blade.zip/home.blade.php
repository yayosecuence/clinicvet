@extends('layouts.app2')
@section('content')



  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 75%;
    height: 100%;
  }
  </style>
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}
</style>
  <style>
.containerr {
  position: relative;
  width: 50%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middlee {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.containerr:hover .imagee {
  opacity: 0.3;
}

.containerr:hover .middlee {
  opacity: 0.2;
}

.textt {
  
  background-color: #DCDCDC;
  color: black;
  font-size: 16px;
  padding: 16px 32px;
}
</style>
  <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script>
$(document).ready(function(){
  $("#myInput2").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable2 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function Pluss(){
var urr=document.getElementById('ur').value;
var mm=document.getElementById('m').value;
var aaaa=document.getElementById('aa').value;
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    
    var myObj = JSON.parse(this.responseText);
    
    document.getElementById("demo").innerHTML = myObj[0].montos;
    document.getElementById("demos").innerHTML = mm;
    
  }
};
xmlhttp.open("GET", "https://mypropertyadmin.com/skylar/servicios/suma_ingresos.php?nombre_urbanizacion="+urr+"&mes="+mm+"&anio="+aaaa, true);
xmlhttp.send();}
</script>

<script>
function Pluss2(){
var urr=document.getElementById('ur').value;
var mm=document.getElementById('m').value;
var aaaa=document.getElementById('aa').value;
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    
    var myObj = JSON.parse(this.responseText);
    
    document.getElementById("demoss").innerHTML = myObj[0].montos;
    
    
  }
};
xmlhttp.open("GET", "https://mypropertyadmin.com/skylar/servicios/suma_egresos.php?nombre_urbanizacion="+urr+"&mes="+mm+"&anio="+aaaa, true);
xmlhttp.send();}
</script>


<script>
function Pluss3(){

  var Row = document.getElementById("obtenertr");
var Cells = Row.getElementsByTagName("td");
var calculo =(parseFloat(Cells[1].innerText)-parseFloat(Cells[2].innerText));calculo
document.getElementById("calculo").innerHTML = calculo;

};

</script>

 @if(Auth::user()->confirmacion=="Acepto")
@if(Auth::user()->estado=="Activado")

<body class="w3-theme-l5">
<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">Mi perfil</h4>
          <div class="containerr">
         
         <p class="w3-center"> 
        <div class="w3-center">
         
             <div align="center">
                      <img src="{{ asset('storage').'/'.Auth::user()->Foto}}" alt="Boss" style="width:70%" class="imagee rounded-circle img-thumbnail" >   
                      </div>
            <div class="middlee">
            <a href="{{url('/'.Auth::user()->id.'/edit2')}}" class="textt" ><i class="fa fa-camera"></i></a>
              </div>
              </div>
                      
         </p>
         </div>
                       <hr>
                      <p><i class=" fa fa-drivers-license fa-fw w3-margin-right w3-text-theme"></i>{{Auth::user()->cedula}}</p>
                      <p><i class=" fa fa-location-arrow fa-fw w3-margin-right w3-text-theme"></i>{{Auth::user()->ciudad}}</p>
                      <p><i class=" fa fa-home fa-fw w3-margin-right w3-text-theme"></i>{{Auth::user()->urbanizacion}}</p>
                      <p><i class=" fa fa-mobile fa-fw w3-margin-right w3-text-theme"></i>{{Auth::user()->telefono}}</p>
        </div>
      </div>
      <br>
      


      <!-- Accordion -->
      <div class="w3-card w3-round">
        <div class="w3-white">
          <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i>Administrativo</button>
            <div id="Demo1" class="w3-hide w3-container">
              <p>
                <div class="card-body">
                             @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                             <button type="button" class="btn btn-link" data-toggle="modal" data-target="#myModal"><i class=" fa fa-reply"></i> Ingresos</button>
                             @endif
                                           <!-- The Modal -->
                                  <div class="modal fade" id="myModal">
                                    <div class="modal-dialog modal-lg">
                                      <div class="modal-content">
                                      
                                        <!-- Modal Header -->
                                        <div class="modal-header">
                                          <h4 class="modal-title">Busca los ingresos por año</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                            </br>
                                           
                                        <!-- Modal body -->
                                        <div class="modal-body">
                                           @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                       <a href="{{url('/ingresos')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                       
                     </br>
                     </br>
                      @endif
                                         <div id="acordion">
                                            <input class="form-control" id="myInput" type="text" placeholder="Search..">
                                            </br>
                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="card-link" data-toggle="collapse" href="#enero">
                                                      Enero
                                                    </a>
                                                  </div>
                                                  <div id="enero" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">

                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Agosto')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#febrero">
                                                      Febrero
                                                    </a>
                                                  </div>
                                                  <div id="febrero" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                     <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Febrero')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#marzo">
                                                      Marzo
                                                    </a>
                                                  </div>
                                                  <div id="marzo" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Marzo')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#abril">
                                                      Abril
                                                    </a>
                                                  </div>
                                                  <div id="abril" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Abril')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#mayo">
                                                      Mayo
                                                    </a>
                                                  </div>
                                                  <div id="mayo" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Mayo')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#junio">
                                                      Junio
                                                    </a>
                                                  </div>
                                                  <div id="junio" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Junio')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#julio">
                                                      Julio
                                                    </a>
                                                  </div>
                                                  <div id="julio" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Julio')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#agosto">
                                                      Agosto
                                                    </a>
                                                  </div>
                                                  <div id="agosto" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Agosto')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#septiembre">
                                                      Septiembre
                                                    </a>
                                                  </div>
                                                  <div id="septiembre" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Septiembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#octubre">
                                                      Octubre
                                                    </a>
                                                  </div>
                                                  <div id="octubre" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Octubre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#noviembre">
                                                      Noviembre
                                                    </a>
                                                  </div>
                                                  <div id="noviembre" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                     <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Noviembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#diciembre">
                                                      Diciembre
                                                    </a>
                                                  </div>
                                                  <div id="diciembre" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Diciembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                        </div>
                                        
                                        <!-- Modal footer -->
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                        
                                      </div>
                                    </div>
                                  </div>
        @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
      <button type="button" class="btn btn-link" data-toggle="modal" data-target="#myModalegresos"><i class=" fa fa-share"></i> Egresos</button>
      @endif
                                     <!-- The Modal -->
                            <div class="modal fade" id="myModalegresos">
                               <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                
                                  <!-- Modal Header -->
                                  <div class="modal-header">
                                    <h4 class="modal-title">Busqueda por año de Gastos generados</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  
                                  <!-- Modal body -->
                                  <div class="modal-body">
                                    <div class="modal-body">
                                       @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                       <a href="{{url('/egresos')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                       
                     </br>
                     </br>
                      @endif
                                         <div id="acordion">
                                            <input class="form-control" id="myInput2" type="text" placeholder="Search..">
                                            </br>
                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="card-link" data-toggle="collapse" href="#enero2">
                                                      Enero
                                                    </a>
                                                  </div>
                                                  <div id="enero2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">

                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Agosto')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#febrero2">
                                                      Febrero
                                                    </a>
                                                  </div>
                                                  <div id="febrero2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                     <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Febrero')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#marzo2">
                                                      Marzo
                                                    </a>
                                                  </div>
                                                  <div id="marzo2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Marzo')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#abril2">
                                                      Abril
                                                    </a>
                                                  </div>
                                                  <div id="abril2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Abril')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#mayo2">
                                                      Mayo
                                                    </a>
                                                  </div>
                                                  <div id="mayo2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">2
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Mayo')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#junio2">
                                                      Junio
                                                    </a>
                                                  </div>
                                                  <div id="junio2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Junio')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#julio2">
                                                      Julio
                                                    </a>
                                                  </div>
                                                  <div id="julio2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Julio')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#agosto2">
                                                      Agosto
                                                    </a>
                                                  </div>
                                                  <div id="agosto2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Agosto')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#septiembre2">
                                                      Septiembre
                                                    </a>
                                                  </div>
                                                  <div id="septiembre2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Septiembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#octubre2">
                                                      Octubre
                                                    </a>
                                                  </div>
                                                  <div id="octubre2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Octubre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#noviembre2">
                                                      Noviembre
                                                    </a>
                                                  </div>
                                                  <div id="noviembre2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                     <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Noviembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="card">
                                                  <div class="card-header">
                                                    <a class="collapsed card-link" data-toggle="collapse" href="#diciembre2">
                                                      Diciembre
                                                    </a>
                                                  </div>
                                                  <div id="diciembre2" class="collapse" data-parent="#acordion">
                                                    <div class="card-body">
                                                      <table class="table table-light">
                                                            <thead class='table-secondary'>
                                                                <tr>
                                                                   <th>#</th>   
                                                                   <th>Monto</th>    
                                                                   <th>Motivo</th> 
                                                                   <th>Año</th>  
                                                                   
                                                                </tr>

                                                            </thead>

                                                            <tbody id="myTable2">
                                                                @foreach($ingresos as $ingreso)
                                                                @if ( Auth::user()->urbanizacion==$ingreso->nombre_urbanizacion && $ingreso->mes=='Diciembre')
                                                                <tr>
                                                                     <td>{{$loop->iteration}}</td>
                                                                     <td>{{$ingreso->monto}}</td>
                                                                     <td>{{$ingreso->motivo}}</td>
                                                                     <td>{{$ingreso->anio}}</td>
                                                                     
                                                                </tr>
                                                                @endif
                                                               @endforeach
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                        </div>
                                  </div>
                                  
                                  <!-- Modal footer -->
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                  </div>
                                  
                                </div>
                              </div>
                            </div>


<button type="button" class="btn btn-link" data-toggle="modal" data-target="#myModalsaldos"><i class=" fa fa-money"></i> Saldos </button>
           <!-- The Modal -->
                          <div class="modal fade" id="myModalsaldos">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                <div class="modal-header">
                                  <h4 class="modal-title">Saldos del Inmoviliar</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                </br>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">Urbanizacion</label>

                                          <div class="col-md-6">
                                              <select class="form-control" name="ur" id="ur" value="">
                                                <option>{{Auth::user()->urbanizacion}}</option>
                                              </select>
                                          </div>
                                      </div>

                                      <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">Mes</label>

                                          <div class="col-md-6">
                                              <select class="form-control" name="m" id="m" value="">
                                               <option>Enero</option>
                                               <option>Febrero</option>
                                               <option>Marzo</option>
                                               <option>Abril</option>
                                               <option>Mayo</option>
                                               <option>Junio</option>
                                               <option>Julio</option>
                                               <option>Agosto</option>
                                               <option>Septiembre</option>
                                               <option>Octubre</option>
                                               <option>Noviembre</option>
                                               <option>Diciembre</option>
                                              </select>
                                          </div>
                                      </div>
                                       
                                       <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">Mes</label>

                                          <div class="col-md-6">
                                              <select class="form-control" name="año" id="aa" value="">
                                                 <option>2019</option>
                                                 <option>2020</option>
                                                 <option>2021</option>
                                                 <option>2022</option>
                                                 <option>2023</option>
                                                 <option>2024</option>

                                                </select>
                                          </div>
                                      </div>

                                      <div class="form-group row mb-0">
                                          <div class="col-md-6 offset-md-4">
                                              <input type="button" class="btn btn-success" name="name" value="Consultar" onclick="Pluss();Pluss2();">
                                        </div>
                                    </div>
                                
                                <!-- Modal body -->
                                <div class="modal-body">
                                  <table class="table table-light" id="miTabla">
                                        <thead class='table-secondary'>
                                            <tr>
                                               <th>Mes</th>   
                                               <th>Ingreso total</th>
                                               <th>Egreso total</th> 
                                               <th>Acciones</th> 

                                               
                                            </tr>

                                        </thead>

                                        <tbody>
                                            
                                            <tr id="obtenertr">
                                                <td id="demos"></td>
                                                <td id="demo"></td>
                                                <td id="demoss"></td>
                                                 <td>
                                                <div class="form-group row mb-0">
                                                    <div class="col-md-6 offset-md-4">
                                                        <input type="button" class="btn btn-success" name="name" value="Calcular saldos" onclick="Pluss3();">
                                                  </div>
                                                   </div>
                                                 </td>
                                            </tr>
                                                                                       
                                        </tbody>

                                    </table>
                                    
                                    
                                    <h1 align="center"> El saldo del Mes </h1>
                                  <h2 id="calculo" style="color: #FF0000;" align="center"></h2>
                                </div>

                                
                                <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                                
                              </div>
                            </div>
                          </div>

             </div>
      
              </p>
          </div>
          <button onclick="myFunction('Demo2')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-calendar-check-o fa-fw w3-margin-right"></i> Insidencias / Obras</button>
          <div id="Demo2" class="w3-hide w3-container">
            <p><a class="card-link" href="" data-toggle="modal" data-target="#myModalinsidencias">
                                              Insidencias / Obras 
              </a>
                                                
                <!-- The Modal -->
                          <div class="modal fade" id="myModalinsidencias">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                  <div class="modal-header">
                                   <h4 class="modal-title">Panel de Incidencias</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="row justify-content-center">
                                    <div class="modal-body">
                                      @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/incidencias')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
                                    <div class="col-md-12">
                                      <div class="card">
               
                                        <table class="table table-light">                                <thead class="thead-light">
                                            <tr>
                                               <th>#</th> 
                                               <th>Incidencia</th>  
                                               <th>Descripcion</th>  
                                               <th>Fecha</th> 
                                               <th>Estado</th>
                                               <th>Foto</th>  
                                            </tr>

                                          </thead>

                                          <tbody>
                                            @foreach($incidencias as $incidencia)
                                                @if ( Auth::user()->urbanizacion==$incidencia->nombre_urbanizacion)
                                            <tr>
                                               <td>{{$loop->iteration}}</td>

                                               
                                               <td>{{$incidencia->insidencia}}</td>
                                               <td>{{$incidencia->descripcion_insidencia}}</td>
                                               <td>{{$incidencia->fecha}}</td>
                                               @if($incidencia->estado=='Sin atender')
                                               <td><span class="badge badge-danger">{{$incidencia->estado}}</span></td>
                                               @endif
                                               @if($incidencia->estado=='Ejecucion')
                                               <td><span class="badge badge-warning">{{$incidencia->estado}}</span></td>
                                               @endif
                                               @if($incidencia->estado=='Culminado')
                                               <td><span  class="badge badge-success">{{$incidencia->estado}}</span></td>
                                               @endif
                                               <td><a href="{{ asset('storage').'/'.$incidencia->Foto}} " target="_blank"><img src="{{ asset('storage').'/'.$incidencia->Foto}}" alt="" width="150" ></a></td>
                                              
                                            </tr>
                                            @endif
                                            @endforeach
                                          </tbody>

                                        </table>

                                    </div>
                                </div>
                         <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                     </div>
                   </p>
          </div>
          <button onclick="myFunction('Demo3')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i>Servicios</button>
          <div id="Demo3" class="w3-hide w3-container">
            <p>

                          <div class="card-body">
                          <a  class="btn btn-link" href="{{ url('/catalogo_servicios') }}"><i class="fa fa-cubes"></i> Catalogo Servicios</a></br>
                          <a  class="btn btn-link" href="{{ url('/bienes_raices') }}"><i class="fa fa-building"></i> Ventas y BIenes Raices</a></br>                     
                          </div>

            </p>
          </div>
          <button onclick="myFunction('Demo4')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i>Documentos</button>
          <div id="Demo4" class="w3-hide w3-container">
            <p>
              <a class="card-link" href="" data-toggle="modal" data-target="#myModalpdf">
                                              Documentos 
                                              </a>
                 <div class="modal fade" id="myModalpdf">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                <div class="modal-header">
                                  <h4 class="modal-title">Descargas de documentos</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                </br>
                                <div class="modal-body">
                                  @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                       <a href="{{url('/subirpdf')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                       
                     </br>
                     </br>
                      @endif
                                        <table class="table table-light">
              <thead class="thead-light">
                <tr>
                   <th>#</th> 
                   <th>Tipo de archivo</th>  
                   <th>Descargar</th>  



                </tr>

              </thead>

              <tbody>
                @foreach($subirpdfs as $subirpdf)
                    @if ( Auth::user()->urbanizacion==$subirpdf->urbanizacion)
                <tr>
                   <td>{{$loop->iteration}}</td>
                   <td>{{$subirpdf->nombre_pdf}}</td>
                   <td><a href="{{ asset('storage').'/'.$subirpdf->pdf}} " target="_blank"><img src="http://www.caldera.cl/2017/wp-content/uploads/2017/06/pdf-logo.png" alt="" width="35" ></a></td>
                  
                </tr>
                @endif
                @endforeach
              </tbody>

            </table>         
</div>
                                <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                                
                              </div>
                           
                          </div>
                                    </div>    
            </p>
          </div>
          <button onclick="myFunction('Demo5')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-users fa-fw w3-margin-right"></i> Elecciones</button>
          <div id="Demo5" class="w3-hide w3-container">
            <p>
               <a  class="btn btn-link" href ="https://mypropertyadmin.com/resultadosvotos"><i class="fa fa-tasks"></i> Resultados de votaciones</a>
                        </br>
                        <a  class="btn btn-link" href="https://mypropertyadmin.com/idvataciones"><i class="fa fa-hand-paper-o"></i> Crear nuevas elecciones</a>
                         </br>
                        <a  class="btn btn-link" href="https://mypropertyadmin.com/votaciones"><i class="fa fa-user-circle-o"></i> Inscribir candidatos</a>
            </p>
          </div>
        </div>      
      </div>
      <br>
      
      
      
      <!-- Alert Box -->
      <div class="w3-container w3-display-container w3-round w3-theme-l4 w3-border w3-theme-border w3-margin-bottom w3-hide-small">
        <span onclick="this.parentElement.style.display='none'" class="w3-button w3-theme-l3 w3-display-topright">
          <i class="fa fa-remove"></i>
        </span>
        <p><strong>Nueva notificacion</strong></p>
        <p>Tenemos una nueva promocion que t gustara</p>
      </div>
    
    <!-- End Left Column -->
    </div>
    
    <!-- Middle Column -->
    <div class="w3-col m7">
    
      <div class="container">
  <div class="jumbotron">
    <div class="media border p-3">
     <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" style="width:60px;">     
      <div class="media-body">
      <h1>Property Admin</h1> 
      <p>Para realizar un mejor trabajo necesitamos de tu ayuda. Por favor da click y ayudanos con tu comentario.</p>   
      <a href="{{url('/reglamentos')}}" class="btn btn-primary">Ir</a>  
    </div>
  </div>
  </div>    
</div>

      
@foreach($noticiasurbanizaciones as $noticiasurbanizacion)
        @if ( Auth::user()->urbanizacion==$noticiasurbanizacion->urbanizacion)
      <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
          @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/noticias_urbanizacions')}}" class="btn btn-success" ><i class="fa fa-cogs"> Publicar Nueva Noticia</i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
        <span class="w3-right w3-opacity">Este se realizara el {{$noticiasurbanizacion->hora}} a las {{$noticiasurbanizacion->hora}}</span>
        <h4>Administracion</h4><br>
        <hr class="w3-clear">
        <p>{{$noticiasurbanizacion->descripcion_noticia}}.</p>
          <div class="w3-row-padding" style="margin:0 -16px">
            <div class="w3-center">
              <img src="{{ asset('storage').'/'.$noticiasurbanizacion->Foto}}" style="width:100%" class="w3-margin-bottom">
            </div>
           
        </div>
        <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom"><i class="fa fa-thumbs-up"></i>  Like</button> 
        <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom"><i class="fa fa-comment"></i>  Comment</button> 
      </div>
      
      @endif
       @endforeach
      
    <!-- End Middle Column -->
    </div>
    

    <!-- Right Column -->


    <div class="w3-col m2">

      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Pagos de alicuotas al dia</p>
          <img src="https://www.mypropertyadmin.com/imagenes_property/alicuotas.png" alt="Avatar" style="width:50%"><br>
          <span>Administracion</span>
           @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                     <div class="w3-row w3-opacity">
            <div class="w3-half">
              <a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalpagos" ><i class="fa fa-eye"></i></a>
            </div>
            <div class="w3-half">
              <a href="{{url('/pagos_alicuotas')}}" class="w3-button w3-block w3-blue w3-section" ><i class="fa fa-cogs"></i></a>
            </div>
          </div>
          @else 
          <p><a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalpagos"><i class="fa fa-eye"></i></a></button></p>
                      @endif
         
        </div>
      </div>

        <div class="modal fade" id="myModalpagos">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                  <div class="modal-header">
                                   <h4 class="modal-title">Panel de Pagos de alicuotas al dia</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="row justify-content-center">
                                    <div class="modal-body">
                                      @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/pagos_alicuotas')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
                                    <div class="col-md-12">
                                      <div class="card">
               
                                         <table class="table table-light">
                    
                                        <thead class='table-secondary'>
                                            <tr>
                                               <th>#</th>   
                                               <th>Nombre</th>    
                                             
                                               <th>Dia del pago</th>
                                               <th>Estado</th> 
                                               


                                            </tr>

                                        </thead>

                                        <tbody>
                                           @foreach($pagosalicuotas as $pagosalicuota)
                                            @if ( Auth::user()->urbanizacion==$pagosalicuota->urbanizacion )
                                             
                                            <tr>
                                                 <td>{{$loop->iteration}}</td>

                                                 <td>{{$pagosalicuota->nombre_persona}}</td>
                                                
                                                 <td>{{$pagosalicuota->dia_pago}}</td>
                                                 <td><span class="badge badge-success">Cancelado</span></td>
                                                 
                                            </tr>
                                            
                                           @endif
                                           @endforeach

                                        </tbody>

                                    </table>

                                    </div>
                                </div>
                         <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                              </div> 

      <br>

      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Horarios de recoleccion de basura:</p>
          <img src="https://www.mypropertyadmin.com/imagenes_property/basura.png" alt="Forest" style="width:100%;">
           @foreach($horariosbasuras as $horariosbasura)
        @if ( Auth::user()->urbanizacion==$horariosbasura->urbanizacion)
          <p><strong>{{$horariosbasura->hora}}</strong></p>
          <p>{{$horariosbasura->dia}}</p>
          @endif
          @endforeach
          @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                     <div class="w3-row w3-opacity">
            <div class="w3-half">
              <a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalbasura" ><i class="fa fa-eye"></i></a>
            </div>
            <div class="w3-half">
              <a href="{{url('/horarios_basuras')}}" class="w3-button w3-block w3-blue w3-section" ><i class="fa fa-cogs"></i></a>
            </div>
          </div>
          @else 
          <p> <a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalbasura" ><i class="fa fa-eye"></i></a></button></p>
                      @endif
                      <div class="modal fade" id="myModalbasura">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                  <div class="modal-header">
                                   <h4 class="modal-title">Panel de horarios de recoleccion</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="row justify-content-center">
                                    <div class="modal-body">
                                      @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/horarios_basuras')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
                                    <div class="col-md-12">
                                      <div class="card">
               
                                        <table class="table table-light">
                      
   <thead class='table-secondary'>
        <tr>
           <th>#</th>   
           <th>Hora</th>    
           <th>Dia</th>  
           <th>Estado</th> 


        </tr>

    </thead>

    <tbody>
        @foreach($horariosbasuras as $horariosbasura)
        @if ( Auth::user()->urbanizacion==$horariosbasura->urbanizacion)
        <tr>
             <td>{{$loop->iteration}}</td>
             <td>{{$horariosbasura->dia}}</td>
             <td>{{$horariosbasura->hora}}</td>
            @if($horariosbasura->dia=='07:00' ||
             $horariosbasura->dia=='07:01' ||
             $horariosbasura->dia=='07:02' ||
             $horariosbasura->dia=='07:03' ||
             $horariosbasura->dia=='07:04' ||
             $horariosbasura->dia=='07:05' ||
             $horariosbasura->dia=='07:06' ||
             $horariosbasura->dia=='07:07' ||
             $horariosbasura->dia=='07:08' ||
             $horariosbasura->dia=='07:09' ||
             $horariosbasura->dia=='07:10' ||
             $horariosbasura->dia=='07:11' ||
             $horariosbasura->dia=='07:12' ||
             $horariosbasura->dia=='07:13' ||
             $horariosbasura->dia=='07:14' ||
             $horariosbasura->dia=='07:15' ||
             $horariosbasura->dia=='07:16' ||
             $horariosbasura->dia=='07:17' ||
             $horariosbasura->dia=='07:18' ||
             $horariosbasura->dia=='07:19' ||
             $horariosbasura->dia=='07:20' ||
             $horariosbasura->dia=='07:21' ||
             $horariosbasura->dia=='07:22' ||
             $horariosbasura->dia=='07:23' ||
             $horariosbasura->dia=='07:24' ||
             $horariosbasura->dia=='07:25' ||
             $horariosbasura->dia=='07:26' ||
             $horariosbasura->dia=='07:27' ||
             $horariosbasura->dia=='07:28' ||
             $horariosbasura->dia=='07:29' ||
             $horariosbasura->dia=='07:30' || 
             $horariosbasura->dia=='07:31' ||
             $horariosbasura->dia=='07:32' ||
             $horariosbasura->dia=='07:33' ||
             $horariosbasura->dia=='07:34' ||
             $horariosbasura->dia=='07:35' ||
             $horariosbasura->dia=='07:36' ||
             $horariosbasura->dia=='07:37' ||
             $horariosbasura->dia=='07:38' ||
             $horariosbasura->dia=='07:39' ||
             $horariosbasura->dia=='07:40' ||
             $horariosbasura->dia=='07:41' ||
             $horariosbasura->dia=='07:42' ||
             $horariosbasura->dia=='07:43' ||
             $horariosbasura->dia=='07:44' ||
             $horariosbasura->dia=='07:45' ||
             $horariosbasura->dia=='07:46' ||
             $horariosbasura->dia=='07:47' ||
             $horariosbasura->dia=='07:48' ||
             $horariosbasura->dia=='07:49' ||
             $horariosbasura->dia=='07:50' ||
             $horariosbasura->dia=='07:51' ||
             $horariosbasura->dia=='07:52' ||
             $horariosbasura->dia=='07:53' ||
             $horariosbasura->dia=='07:54' ||
             $horariosbasura->dia=='07:55' ||
             $horariosbasura->dia=='07:56' ||
             $horariosbasura->dia=='07:57' ||
             $horariosbasura->dia=='07:58' ||
             $horariosbasura->dia=='07:59' ||

             $horariosbasura->dia=='08:00' ||
             $horariosbasura->dia=='08:01' ||
             $horariosbasura->dia=='08:02' ||
             $horariosbasura->dia=='08:03' ||
             $horariosbasura->dia=='08:04' ||
             $horariosbasura->dia=='08:05' ||
             $horariosbasura->dia=='08:06' ||
             $horariosbasura->dia=='08:07' ||
             $horariosbasura->dia=='08:08' ||
             $horariosbasura->dia=='08:09' ||
             $horariosbasura->dia=='08:10' ||
             $horariosbasura->dia=='08:11' ||
             $horariosbasura->dia=='08:12' ||
             $horariosbasura->dia=='08:13' ||
             $horariosbasura->dia=='08:14' ||
             $horariosbasura->dia=='08:15' ||
             $horariosbasura->dia=='08:16' ||
             $horariosbasura->dia=='08:17' ||
             $horariosbasura->dia=='08:18' ||
             $horariosbasura->dia=='08:19' ||
             $horariosbasura->dia=='08:20' ||
             $horariosbasura->dia=='08:21' ||
             $horariosbasura->dia=='08:22' ||
             $horariosbasura->dia=='08:23' ||
             $horariosbasura->dia=='08:24' ||
             $horariosbasura->dia=='08:25' ||
             $horariosbasura->dia=='08:26' ||
             $horariosbasura->dia=='08:27' ||
             $horariosbasura->dia=='08:28' ||
             $horariosbasura->dia=='08:29' ||
             $horariosbasura->dia=='08:30' || 
             $horariosbasura->dia=='08:31' ||
             $horariosbasura->dia=='08:32' ||
             $horariosbasura->dia=='08:33' ||
             $horariosbasura->dia=='08:34' ||
             $horariosbasura->dia=='08:35' ||
             $horariosbasura->dia=='08:36' ||
             $horariosbasura->dia=='08:37' ||
             $horariosbasura->dia=='08:38' ||
             $horariosbasura->dia=='08:39' ||
             $horariosbasura->dia=='08:40' ||
             $horariosbasura->dia=='08:41' ||
             $horariosbasura->dia=='08:42' ||
             $horariosbasura->dia=='08:43' ||
             $horariosbasura->dia=='08:44' ||
             $horariosbasura->dia=='08:45' ||
             $horariosbasura->dia=='08:46' ||
             $horariosbasura->dia=='08:47' ||
             $horariosbasura->dia=='08:48' ||
             $horariosbasura->dia=='08:49' ||
             $horariosbasura->dia=='08:50' ||
             $horariosbasura->dia=='08:51' ||
             $horariosbasura->dia=='08:52' ||
             $horariosbasura->dia=='08:53' ||
             $horariosbasura->dia=='08:54' ||
             $horariosbasura->dia=='08:55' ||
             $horariosbasura->dia=='08:56' ||
             $horariosbasura->dia=='08:57' ||
             $horariosbasura->dia=='08:58' ||
             $horariosbasura->dia=='08:59' ||

              $horariosbasura->dia=='09:00' ||
             $horariosbasura->dia=='09:01' ||
             $horariosbasura->dia=='09:02' ||
             $horariosbasura->dia=='09:03' ||
             $horariosbasura->dia=='09:04' ||
             $horariosbasura->dia=='09:05' ||
             $horariosbasura->dia=='09:06' ||
             $horariosbasura->dia=='09:07' ||
             $horariosbasura->dia=='09:08' ||
             $horariosbasura->dia=='09:09' ||
             $horariosbasura->dia=='09:10' ||
             $horariosbasura->dia=='09:11' ||
             $horariosbasura->dia=='09:12' ||
             $horariosbasura->dia=='09:13' ||
             $horariosbasura->dia=='09:14' ||
             $horariosbasura->dia=='09:15' ||
             $horariosbasura->dia=='09:16' ||
             $horariosbasura->dia=='09:17' ||
             $horariosbasura->dia=='09:18' ||
             $horariosbasura->dia=='09:19' ||
             $horariosbasura->dia=='09:20' ||
             $horariosbasura->dia=='09:21' ||
             $horariosbasura->dia=='09:22' ||
             $horariosbasura->dia=='09:23' ||
             $horariosbasura->dia=='09:24' ||
             $horariosbasura->dia=='09:25' ||
             $horariosbasura->dia=='09:26' ||
             $horariosbasura->dia=='09:27' ||
             $horariosbasura->dia=='09:28' ||
             $horariosbasura->dia=='09:29' ||
             $horariosbasura->dia=='09:30' || 
             $horariosbasura->dia=='09:31' ||
             $horariosbasura->dia=='09:32' ||
             $horariosbasura->dia=='09:33' ||
             $horariosbasura->dia=='09:34' ||
             $horariosbasura->dia=='09:35' ||
             $horariosbasura->dia=='09:36' ||
             $horariosbasura->dia=='09:37' ||
             $horariosbasura->dia=='09:38' ||
             $horariosbasura->dia=='09:39' ||
             $horariosbasura->dia=='09:40' ||
             $horariosbasura->dia=='09:41' ||
             $horariosbasura->dia=='09:42' ||
             $horariosbasura->dia=='09:43' ||
             $horariosbasura->dia=='09:44' ||
             $horariosbasura->dia=='09:45' ||
             $horariosbasura->dia=='09:46' ||
             $horariosbasura->dia=='09:47' ||
             $horariosbasura->dia=='09:48' ||
             $horariosbasura->dia=='09:49' ||
             $horariosbasura->dia=='09:50' ||
             $horariosbasura->dia=='09:51' ||
             $horariosbasura->dia=='09:52' ||
             $horariosbasura->dia=='09:53' ||
             $horariosbasura->dia=='09:54' ||
             $horariosbasura->dia=='09:55' ||
             $horariosbasura->dia=='09:56' ||
             $horariosbasura->dia=='09:57' ||
             $horariosbasura->dia=='09:58' ||
             $horariosbasura->dia=='09:59' ||

             $horariosbasura->dia=='10:00' ||
             $horariosbasura->dia=='10:01' ||
             $horariosbasura->dia=='10:02' ||
             $horariosbasura->dia=='10:03' ||
             $horariosbasura->dia=='10:04' ||
             $horariosbasura->dia=='10:05' ||
             $horariosbasura->dia=='10:06' ||
             $horariosbasura->dia=='10:07' ||
             $horariosbasura->dia=='10:08' ||
             $horariosbasura->dia=='10:09' ||
             $horariosbasura->dia=='10:10' ||
             $horariosbasura->dia=='10:11' ||
             $horariosbasura->dia=='10:12' ||
             $horariosbasura->dia=='10:13' ||
             $horariosbasura->dia=='10:14' ||
             $horariosbasura->dia=='10:15' ||
             $horariosbasura->dia=='10:16' ||
             $horariosbasura->dia=='10:17' ||
             $horariosbasura->dia=='10:18' ||
             $horariosbasura->dia=='10:19' ||
             $horariosbasura->dia=='10:20' ||
             $horariosbasura->dia=='10:21' ||
             $horariosbasura->dia=='10:22' ||
             $horariosbasura->dia=='10:23' ||
             $horariosbasura->dia=='10:24' ||
             $horariosbasura->dia=='10:25' ||
             $horariosbasura->dia=='10:26' ||
             $horariosbasura->dia=='10:27' ||
             $horariosbasura->dia=='10:28' ||
             $horariosbasura->dia=='10:29' ||
             $horariosbasura->dia=='10:30' || 
             $horariosbasura->dia=='10:31' ||
             $horariosbasura->dia=='10:32' ||
             $horariosbasura->dia=='10:33' ||
             $horariosbasura->dia=='10:34' ||
             $horariosbasura->dia=='10:35' ||
             $horariosbasura->dia=='10:36' ||
             $horariosbasura->dia=='10:37' ||
             $horariosbasura->dia=='10:38' ||
             $horariosbasura->dia=='10:39' ||
             $horariosbasura->dia=='10:40' ||
             $horariosbasura->dia=='10:41' ||
             $horariosbasura->dia=='10:42' ||
             $horariosbasura->dia=='10:43' ||
             $horariosbasura->dia=='10:44' ||
             $horariosbasura->dia=='10:45' ||
             $horariosbasura->dia=='10:46' ||
             $horariosbasura->dia=='10:47' ||
             $horariosbasura->dia=='10:48' ||
             $horariosbasura->dia=='10:49' ||
             $horariosbasura->dia=='10:50' ||
             $horariosbasura->dia=='10:51' ||
             $horariosbasura->dia=='10:52' ||
             $horariosbasura->dia=='10:53' ||
             $horariosbasura->dia=='10:54' ||
             $horariosbasura->dia=='10:55' ||
             $horariosbasura->dia=='10:56' ||
             $horariosbasura->dia=='10:57' ||
             $horariosbasura->dia=='10:58' ||
             $horariosbasura->dia=='10:59' ||

             $horariosbasura->dia=='11:00' ||
             $horariosbasura->dia=='11:01' ||
             $horariosbasura->dia=='11:02' ||
             $horariosbasura->dia=='11:03' ||
             $horariosbasura->dia=='11:04' ||
             $horariosbasura->dia=='11:05' ||
             $horariosbasura->dia=='11:06' ||
             $horariosbasura->dia=='11:07' ||
             $horariosbasura->dia=='11:08' ||
             $horariosbasura->dia=='11:09' ||
             $horariosbasura->dia=='11:10' ||
             $horariosbasura->dia=='11:11' ||
             $horariosbasura->dia=='11:12' ||
             $horariosbasura->dia=='11:13' ||
             $horariosbasura->dia=='11:14' ||
             $horariosbasura->dia=='11:15' ||
             $horariosbasura->dia=='11:16' ||
             $horariosbasura->dia=='11:17' ||
             $horariosbasura->dia=='11:18' ||
             $horariosbasura->dia=='11:19' ||
             $horariosbasura->dia=='11:20' ||
             $horariosbasura->dia=='11:21' ||
             $horariosbasura->dia=='11:22' ||
             $horariosbasura->dia=='11:23' ||
             $horariosbasura->dia=='11:24' ||
             $horariosbasura->dia=='11:25' ||
             $horariosbasura->dia=='11:26' ||
             $horariosbasura->dia=='11:27' ||
             $horariosbasura->dia=='11:28' ||
             $horariosbasura->dia=='11:29' ||
             $horariosbasura->dia=='11:30' || 
             $horariosbasura->dia=='11:31' ||
             $horariosbasura->dia=='11:32' ||
             $horariosbasura->dia=='11:33' ||
             $horariosbasura->dia=='11:34' ||
             $horariosbasura->dia=='11:35' ||
             $horariosbasura->dia=='11:36' ||
             $horariosbasura->dia=='11:37' ||
             $horariosbasura->dia=='11:38' ||
             $horariosbasura->dia=='11:39' ||
             $horariosbasura->dia=='11:40' ||
             $horariosbasura->dia=='11:41' ||
             $horariosbasura->dia=='11:42' ||
             $horariosbasura->dia=='11:43' ||
             $horariosbasura->dia=='11:44' ||
             $horariosbasura->dia=='11:45' ||
             $horariosbasura->dia=='11:46' ||
             $horariosbasura->dia=='11:47' ||
             $horariosbasura->dia=='11:48' ||
             $horariosbasura->dia=='11:49' ||
             $horariosbasura->dia=='11:50' ||
             $horariosbasura->dia=='11:51' ||
             $horariosbasura->dia=='11:52' ||
             $horariosbasura->dia=='11:53' ||
             $horariosbasura->dia=='11:54' ||
             $horariosbasura->dia=='11:55' ||
             $horariosbasura->dia=='11:56' ||
             $horariosbasura->dia=='11:57' ||
             $horariosbasura->dia=='11:58' ||
             $horariosbasura->dia=='11:59' ||

             $horariosbasura->dia=='12:00' ||
             $horariosbasura->dia=='12:01' ||
             $horariosbasura->dia=='12:02' ||
             $horariosbasura->dia=='12:03' ||
             $horariosbasura->dia=='12:04' ||
             $horariosbasura->dia=='12:05' ||
             $horariosbasura->dia=='12:06' ||
             $horariosbasura->dia=='12:07' ||
             $horariosbasura->dia=='12:08' ||
             $horariosbasura->dia=='12:09' ||
             $horariosbasura->dia=='12:10' ||
             $horariosbasura->dia=='12:11' ||
             $horariosbasura->dia=='12:12' ||
             $horariosbasura->dia=='12:13' ||
             $horariosbasura->dia=='12:14' ||
             $horariosbasura->dia=='12:15' ||
             $horariosbasura->dia=='12:16' ||
             $horariosbasura->dia=='12:17' ||
             $horariosbasura->dia=='12:18' ||
             $horariosbasura->dia=='12:19' ||
             $horariosbasura->dia=='12:20' ||
             $horariosbasura->dia=='12:21' ||
             $horariosbasura->dia=='12:22' ||
             $horariosbasura->dia=='12:23' ||
             $horariosbasura->dia=='12:24' ||
             $horariosbasura->dia=='12:25' ||
             $horariosbasura->dia=='12:26' ||
             $horariosbasura->dia=='12:27' ||
             $horariosbasura->dia=='12:28' ||
             $horariosbasura->dia=='12:29' ||
             $horariosbasura->dia=='12:30' || 
             $horariosbasura->dia=='12:31' ||
             $horariosbasura->dia=='12:32' ||
             $horariosbasura->dia=='12:33' ||
             $horariosbasura->dia=='12:34' ||
             $horariosbasura->dia=='12:35' ||
             $horariosbasura->dia=='12:36' ||
             $horariosbasura->dia=='12:37' ||
             $horariosbasura->dia=='12:38' ||
             $horariosbasura->dia=='12:39' ||
             $horariosbasura->dia=='12:40' ||
             $horariosbasura->dia=='12:41' ||
             $horariosbasura->dia=='12:42' ||
             $horariosbasura->dia=='12:43' ||
             $horariosbasura->dia=='12:44' ||
             $horariosbasura->dia=='12:45' ||
             $horariosbasura->dia=='12:46' ||
             $horariosbasura->dia=='12:47' ||
             $horariosbasura->dia=='12:48' ||
             $horariosbasura->dia=='12:49' ||
             $horariosbasura->dia=='12:50' ||
             $horariosbasura->dia=='12:51' ||
             $horariosbasura->dia=='12:52' ||
             $horariosbasura->dia=='12:53' ||
             $horariosbasura->dia=='12:54' ||
             $horariosbasura->dia=='12:55' ||
             $horariosbasura->dia=='12:56' ||
             $horariosbasura->dia=='12:57' ||
             $horariosbasura->dia=='12:58' ||
             $horariosbasura->dia=='12:59' )
              <td><span class="badge badge-primary">Mañana</span></td>
             @endif
             @if($horariosbasura->dia=='13:00' ||
             $horariosbasura->dia=='13:01' ||
             $horariosbasura->dia=='13:02' ||
             $horariosbasura->dia=='13:03' ||
             $horariosbasura->dia=='13:04' ||
             $horariosbasura->dia=='13:05' ||
             $horariosbasura->dia=='13:06' ||
             $horariosbasura->dia=='13:07' ||
             $horariosbasura->dia=='13:08' ||
             $horariosbasura->dia=='13:09' ||
             $horariosbasura->dia=='13:10' ||
             $horariosbasura->dia=='13:11' ||
             $horariosbasura->dia=='13:12' ||
             $horariosbasura->dia=='13:13' ||
             $horariosbasura->dia=='13:14' ||
             $horariosbasura->dia=='13:15' ||
             $horariosbasura->dia=='13:16' ||
             $horariosbasura->dia=='13:17' ||
             $horariosbasura->dia=='13:18' ||
             $horariosbasura->dia=='13:19' ||
             $horariosbasura->dia=='13:20' ||
             $horariosbasura->dia=='13:21' ||
             $horariosbasura->dia=='13:22' ||
             $horariosbasura->dia=='13:23' ||
             $horariosbasura->dia=='13:24' ||
             $horariosbasura->dia=='13:25' ||
             $horariosbasura->dia=='13:26' ||
             $horariosbasura->dia=='13:27' ||
             $horariosbasura->dia=='13:28' ||
             $horariosbasura->dia=='13:29' ||
             $horariosbasura->dia=='13:30' || 
             $horariosbasura->dia=='13:31' ||
             $horariosbasura->dia=='13:32' ||
             $horariosbasura->dia=='13:33' ||
             $horariosbasura->dia=='13:34' ||
             $horariosbasura->dia=='13:35' ||
             $horariosbasura->dia=='13:36' ||
             $horariosbasura->dia=='13:37' ||
             $horariosbasura->dia=='13:38' ||
             $horariosbasura->dia=='13:39' ||
             $horariosbasura->dia=='13:40' ||
             $horariosbasura->dia=='13:41' ||
             $horariosbasura->dia=='13:42' ||
             $horariosbasura->dia=='13:43' ||
             $horariosbasura->dia=='13:44' ||
             $horariosbasura->dia=='13:45' ||
             $horariosbasura->dia=='13:46' ||
             $horariosbasura->dia=='13:47' ||
             $horariosbasura->dia=='13:48' ||
             $horariosbasura->dia=='13:49' ||
             $horariosbasura->dia=='13:50' ||
             $horariosbasura->dia=='13:51' ||
             $horariosbasura->dia=='13:52' ||
             $horariosbasura->dia=='13:53' ||
             $horariosbasura->dia=='13:54' ||
             $horariosbasura->dia=='13:55' ||
             $horariosbasura->dia=='13:56' ||
             $horariosbasura->dia=='13:57' ||
             $horariosbasura->dia=='13:58' ||
             $horariosbasura->dia=='13:59' ||

             $horariosbasura->dia=='14:00' ||
             $horariosbasura->dia=='14:01' ||
             $horariosbasura->dia=='14:02' ||
             $horariosbasura->dia=='14:03' ||
             $horariosbasura->dia=='14:04' ||
             $horariosbasura->dia=='14:05' ||
             $horariosbasura->dia=='14:06' ||
             $horariosbasura->dia=='14:07' ||
             $horariosbasura->dia=='14:08' ||
             $horariosbasura->dia=='14:09' ||
             $horariosbasura->dia=='14:10' ||
             $horariosbasura->dia=='14:11' ||
             $horariosbasura->dia=='14:12' ||
             $horariosbasura->dia=='14:13' ||
             $horariosbasura->dia=='14:14' ||
             $horariosbasura->dia=='14:15' ||
             $horariosbasura->dia=='14:16' ||
             $horariosbasura->dia=='14:17' ||
             $horariosbasura->dia=='14:18' ||
             $horariosbasura->dia=='14:19' ||
             $horariosbasura->dia=='14:20' ||
             $horariosbasura->dia=='14:21' ||
             $horariosbasura->dia=='14:22' ||
             $horariosbasura->dia=='14:23' ||
             $horariosbasura->dia=='14:24' ||
             $horariosbasura->dia=='14:25' ||
             $horariosbasura->dia=='14:26' ||
             $horariosbasura->dia=='14:27' ||
             $horariosbasura->dia=='14:28' ||
             $horariosbasura->dia=='14:29' ||
             $horariosbasura->dia=='14:30' || 
             $horariosbasura->dia=='14:31' ||
             $horariosbasura->dia=='14:32' ||
             $horariosbasura->dia=='14:33' ||
             $horariosbasura->dia=='14:34' ||
             $horariosbasura->dia=='14:35' ||
             $horariosbasura->dia=='14:36' ||
             $horariosbasura->dia=='14:37' ||
             $horariosbasura->dia=='14:38' ||
             $horariosbasura->dia=='14:39' ||
             $horariosbasura->dia=='14:40' ||
             $horariosbasura->dia=='14:41' ||
             $horariosbasura->dia=='14:42' ||
             $horariosbasura->dia=='14:43' ||
             $horariosbasura->dia=='14:44' ||
             $horariosbasura->dia=='14:45' ||
             $horariosbasura->dia=='14:46' ||
             $horariosbasura->dia=='14:47' ||
             $horariosbasura->dia=='14:48' ||
             $horariosbasura->dia=='14:49' ||
             $horariosbasura->dia=='14:50' ||
             $horariosbasura->dia=='14:51' ||
             $horariosbasura->dia=='14:52' ||
             $horariosbasura->dia=='14:53' ||
             $horariosbasura->dia=='14:54' ||
             $horariosbasura->dia=='14:55' ||
             $horariosbasura->dia=='14:56' ||
             $horariosbasura->dia=='14:57' ||
             $horariosbasura->dia=='14:58' ||
             $horariosbasura->dia=='14:59' ||

             $horariosbasura->dia=='15:00' ||
             $horariosbasura->dia=='15:01' ||
             $horariosbasura->dia=='15:02' ||
             $horariosbasura->dia=='15:03' ||
             $horariosbasura->dia=='15:04' ||
             $horariosbasura->dia=='15:05' ||
             $horariosbasura->dia=='15:06' ||
             $horariosbasura->dia=='15:07' ||
             $horariosbasura->dia=='15:08' ||
             $horariosbasura->dia=='15:09' ||
             $horariosbasura->dia=='15:10' ||
             $horariosbasura->dia=='15:11' ||
             $horariosbasura->dia=='15:12' ||
             $horariosbasura->dia=='15:13' ||
             $horariosbasura->dia=='15:14' ||
             $horariosbasura->dia=='15:15' ||
             $horariosbasura->dia=='15:16' ||
             $horariosbasura->dia=='15:17' ||
             $horariosbasura->dia=='15:18' ||
             $horariosbasura->dia=='15:19' ||
             $horariosbasura->dia=='15:20' ||
             $horariosbasura->dia=='15:21' ||
             $horariosbasura->dia=='15:22' ||
             $horariosbasura->dia=='15:23' ||
             $horariosbasura->dia=='15:24' ||
             $horariosbasura->dia=='15:25' ||
             $horariosbasura->dia=='15:26' ||
             $horariosbasura->dia=='15:27' ||
             $horariosbasura->dia=='15:28' ||
             $horariosbasura->dia=='15:29' ||
             $horariosbasura->dia=='15:30' || 
             $horariosbasura->dia=='15:31' ||
             $horariosbasura->dia=='15:32' ||
             $horariosbasura->dia=='15:33' ||
             $horariosbasura->dia=='15:34' ||
             $horariosbasura->dia=='15:35' ||
             $horariosbasura->dia=='15:36' ||
             $horariosbasura->dia=='15:37' ||
             $horariosbasura->dia=='15:38' ||
             $horariosbasura->dia=='15:39' ||
             $horariosbasura->dia=='15:40' ||
             $horariosbasura->dia=='15:41' ||
             $horariosbasura->dia=='15:42' ||
             $horariosbasura->dia=='15:43' ||
             $horariosbasura->dia=='15:44' ||
             $horariosbasura->dia=='15:45' ||
             $horariosbasura->dia=='15:46' ||
             $horariosbasura->dia=='15:47' ||
             $horariosbasura->dia=='15:48' ||
             $horariosbasura->dia=='15:49' ||
             $horariosbasura->dia=='15:50' ||
             $horariosbasura->dia=='15:51' ||
             $horariosbasura->dia=='15:52' ||
             $horariosbasura->dia=='15:53' ||
             $horariosbasura->dia=='15:54' ||
             $horariosbasura->dia=='15:55' ||
             $horariosbasura->dia=='15:56' ||
             $horariosbasura->dia=='15:57' ||
             $horariosbasura->dia=='15:58' ||
             $horariosbasura->dia=='15:59' ||

             $horariosbasura->dia=='16:00' ||
             $horariosbasura->dia=='16:01' ||
             $horariosbasura->dia=='16:02' ||
             $horariosbasura->dia=='16:03' ||
             $horariosbasura->dia=='16:04' ||
             $horariosbasura->dia=='16:05' ||
             $horariosbasura->dia=='16:06' ||
             $horariosbasura->dia=='16:07' ||
             $horariosbasura->dia=='16:08' ||
             $horariosbasura->dia=='16:09' ||
             $horariosbasura->dia=='16:10' ||
             $horariosbasura->dia=='16:11' ||
             $horariosbasura->dia=='16:12' ||
             $horariosbasura->dia=='16:13' ||
             $horariosbasura->dia=='16:14' ||
             $horariosbasura->dia=='16:15' ||
             $horariosbasura->dia=='16:16' ||
             $horariosbasura->dia=='16:17' ||
             $horariosbasura->dia=='16:18' ||
             $horariosbasura->dia=='16:19' ||
             $horariosbasura->dia=='16:20' ||
             $horariosbasura->dia=='16:21' ||
             $horariosbasura->dia=='16:22' ||
             $horariosbasura->dia=='16:23' ||
             $horariosbasura->dia=='16:24' ||
             $horariosbasura->dia=='16:25' ||
             $horariosbasura->dia=='16:26' ||
             $horariosbasura->dia=='16:27' ||
             $horariosbasura->dia=='16:28' ||
             $horariosbasura->dia=='16:29' ||
             $horariosbasura->dia=='16:30' || 
             $horariosbasura->dia=='16:31' ||
             $horariosbasura->dia=='16:32' ||
             $horariosbasura->dia=='16:33' ||
             $horariosbasura->dia=='16:34' ||
             $horariosbasura->dia=='16:35' ||
             $horariosbasura->dia=='16:36' ||
             $horariosbasura->dia=='16:37' ||
             $horariosbasura->dia=='16:38' ||
             $horariosbasura->dia=='16:39' ||
             $horariosbasura->dia=='16:40' ||
             $horariosbasura->dia=='16:41' ||
             $horariosbasura->dia=='16:42' ||
             $horariosbasura->dia=='16:43' ||
             $horariosbasura->dia=='16:44' ||
             $horariosbasura->dia=='16:45' ||
             $horariosbasura->dia=='16:46' ||
             $horariosbasura->dia=='16:47' ||
             $horariosbasura->dia=='16:48' ||
             $horariosbasura->dia=='16:49' ||
             $horariosbasura->dia=='16:50' ||
             $horariosbasura->dia=='16:51' ||
             $horariosbasura->dia=='16:52' ||
             $horariosbasura->dia=='16:53' ||
             $horariosbasura->dia=='16:54' ||
             $horariosbasura->dia=='16:55' ||
             $horariosbasura->dia=='16:56' ||
             $horariosbasura->dia=='16:57' ||
             $horariosbasura->dia=='16:58' ||
             $horariosbasura->dia=='16:59' ||

             $horariosbasura->dia=='17:00' ||
             $horariosbasura->dia=='17:01' ||
             $horariosbasura->dia=='17:02' ||
             $horariosbasura->dia=='17:03' ||
             $horariosbasura->dia=='17:04' ||
             $horariosbasura->dia=='17:05' ||
             $horariosbasura->dia=='17:06' ||
             $horariosbasura->dia=='17:07' ||
             $horariosbasura->dia=='17:08' ||
             $horariosbasura->dia=='17:09' ||
             $horariosbasura->dia=='17:10' ||
             $horariosbasura->dia=='17:11' ||
             $horariosbasura->dia=='17:12' ||
             $horariosbasura->dia=='17:13' ||
             $horariosbasura->dia=='17:14' ||
             $horariosbasura->dia=='17:15' ||
             $horariosbasura->dia=='17:16' ||
             $horariosbasura->dia=='17:17' ||
             $horariosbasura->dia=='17:18' ||
             $horariosbasura->dia=='17:19' ||
             $horariosbasura->dia=='17:20' ||
             $horariosbasura->dia=='17:21' ||
             $horariosbasura->dia=='17:22' ||
             $horariosbasura->dia=='17:23' ||
             $horariosbasura->dia=='17:24' ||
             $horariosbasura->dia=='17:25' ||
             $horariosbasura->dia=='17:26' ||
             $horariosbasura->dia=='17:27' ||
             $horariosbasura->dia=='17:28' ||
             $horariosbasura->dia=='17:29' ||
             $horariosbasura->dia=='17:30' || 
             $horariosbasura->dia=='17:31' ||
             $horariosbasura->dia=='17:32' ||
             $horariosbasura->dia=='17:33' ||
             $horariosbasura->dia=='17:34' ||
             $horariosbasura->dia=='17:35' ||
             $horariosbasura->dia=='17:36' ||
             $horariosbasura->dia=='17:37' ||
             $horariosbasura->dia=='17:38' ||
             $horariosbasura->dia=='17:39' ||
             $horariosbasura->dia=='17:40' ||
             $horariosbasura->dia=='17:41' ||
             $horariosbasura->dia=='17:42' ||
             $horariosbasura->dia=='17:43' ||
             $horariosbasura->dia=='17:44' ||
             $horariosbasura->dia=='17:45' ||
             $horariosbasura->dia=='17:46' ||
             $horariosbasura->dia=='17:47' ||
             $horariosbasura->dia=='17:48' ||
             $horariosbasura->dia=='17:49' ||
             $horariosbasura->dia=='17:50' ||
             $horariosbasura->dia=='17:51' ||
             $horariosbasura->dia=='17:52' ||
             $horariosbasura->dia=='17:53' ||
             $horariosbasura->dia=='17:54' ||
             $horariosbasura->dia=='17:55' ||
             $horariosbasura->dia=='17:56' ||
             $horariosbasura->dia=='17:57' ||
             $horariosbasura->dia=='17:58' ||
             $horariosbasura->dia=='17:59' ||

             $horariosbasura->dia=='18:00' ||
             $horariosbasura->dia=='18:01' ||
             $horariosbasura->dia=='18:02' ||
             $horariosbasura->dia=='18:03' ||
             $horariosbasura->dia=='18:04' ||
             $horariosbasura->dia=='18:05' ||
             $horariosbasura->dia=='18:06' ||
             $horariosbasura->dia=='18:07' ||
             $horariosbasura->dia=='18:08' ||
             $horariosbasura->dia=='18:09' ||
             $horariosbasura->dia=='18:10' ||
             $horariosbasura->dia=='18:11' ||
             $horariosbasura->dia=='18:12' ||
             $horariosbasura->dia=='18:13' ||
             $horariosbasura->dia=='18:14' ||
             $horariosbasura->dia=='18:15' ||
             $horariosbasura->dia=='18:16' ||
             $horariosbasura->dia=='18:17' ||
             $horariosbasura->dia=='18:18' ||
             $horariosbasura->dia=='18:19' ||
             $horariosbasura->dia=='18:20' ||
             $horariosbasura->dia=='18:21' ||
             $horariosbasura->dia=='18:22' ||
             $horariosbasura->dia=='18:23' ||
             $horariosbasura->dia=='18:24' ||
             $horariosbasura->dia=='18:25' ||
             $horariosbasura->dia=='18:26' ||
             $horariosbasura->dia=='18:27' ||
             $horariosbasura->dia=='18:28' ||
             $horariosbasura->dia=='18:29' ||
             $horariosbasura->dia=='18:30' || 
             $horariosbasura->dia=='18:31' ||
             $horariosbasura->dia=='18:32' ||
             $horariosbasura->dia=='18:33' ||
             $horariosbasura->dia=='18:34' ||
             $horariosbasura->dia=='18:35' ||
             $horariosbasura->dia=='18:36' ||
             $horariosbasura->dia=='18:37' ||
             $horariosbasura->dia=='18:38' ||
             $horariosbasura->dia=='18:39' ||
             $horariosbasura->dia=='18:40' ||
             $horariosbasura->dia=='18:41' ||
             $horariosbasura->dia=='18:42' ||
             $horariosbasura->dia=='18:43' ||
             $horariosbasura->dia=='18:44' ||
             $horariosbasura->dia=='18:45' ||
             $horariosbasura->dia=='18:46' ||
             $horariosbasura->dia=='18:47' ||
             $horariosbasura->dia=='18:48' ||
             $horariosbasura->dia=='18:49' ||
             $horariosbasura->dia=='18:50' ||
             $horariosbasura->dia=='18:51' ||
             $horariosbasura->dia=='18:52' ||
             $horariosbasura->dia=='18:53' ||
             $horariosbasura->dia=='18:54' ||
             $horariosbasura->dia=='18:55' ||
             $horariosbasura->dia=='18:56' ||
             $horariosbasura->dia=='18:57' ||
             $horariosbasura->dia=='18:58' ||
             $horariosbasura->dia=='18:59'
 )
              <td><span class="badge badge-warning">Tarde</span></td>
             @endif
             @if($horariosbasura->dia=='19:00' ||
             $horariosbasura->dia=='19:01' ||
             $horariosbasura->dia=='19:02' ||
             $horariosbasura->dia=='19:03' ||
             $horariosbasura->dia=='19:04' ||
             $horariosbasura->dia=='19:05' ||
             $horariosbasura->dia=='19:06' ||
             $horariosbasura->dia=='19:07' ||
             $horariosbasura->dia=='19:08' ||
             $horariosbasura->dia=='19:09' ||
             $horariosbasura->dia=='19:10' ||
             $horariosbasura->dia=='19:11' ||
             $horariosbasura->dia=='19:12' ||
             $horariosbasura->dia=='19:13' ||
             $horariosbasura->dia=='19:14' ||
             $horariosbasura->dia=='19:15' ||
             $horariosbasura->dia=='19:16' ||
             $horariosbasura->dia=='19:17' ||
             $horariosbasura->dia=='19:18' ||
             $horariosbasura->dia=='19:19' ||
             $horariosbasura->dia=='19:20' ||
             $horariosbasura->dia=='19:21' ||
             $horariosbasura->dia=='19:22' ||
             $horariosbasura->dia=='19:23' ||
             $horariosbasura->dia=='19:24' ||
             $horariosbasura->dia=='19:25' ||
             $horariosbasura->dia=='19:26' ||
             $horariosbasura->dia=='19:27' ||
             $horariosbasura->dia=='19:28' ||
             $horariosbasura->dia=='19:29' ||
             $horariosbasura->dia=='19:30' || 
             $horariosbasura->dia=='19:31' ||
             $horariosbasura->dia=='19:32' ||
             $horariosbasura->dia=='19:33' ||
             $horariosbasura->dia=='19:34' ||
             $horariosbasura->dia=='19:35' ||
             $horariosbasura->dia=='19:36' ||
             $horariosbasura->dia=='19:37' ||
             $horariosbasura->dia=='19:38' ||
             $horariosbasura->dia=='19:39' ||
             $horariosbasura->dia=='19:40' ||
             $horariosbasura->dia=='19:41' ||
             $horariosbasura->dia=='19:42' ||
             $horariosbasura->dia=='19:43' ||
             $horariosbasura->dia=='19:44' ||
             $horariosbasura->dia=='19:45' ||
             $horariosbasura->dia=='19:46' ||
             $horariosbasura->dia=='19:47' ||
             $horariosbasura->dia=='19:48' ||
             $horariosbasura->dia=='19:49' ||
             $horariosbasura->dia=='19:50' ||
             $horariosbasura->dia=='19:51' ||
             $horariosbasura->dia=='19:52' ||
             $horariosbasura->dia=='19:53' ||
             $horariosbasura->dia=='19:54' ||
             $horariosbasura->dia=='19:55' ||
             $horariosbasura->dia=='19:56' ||
             $horariosbasura->dia=='19:57' ||
             $horariosbasura->dia=='19:58' ||
             $horariosbasura->dia=='19:59' ||  

             $horariosbasura->dia=='20:00' ||
             $horariosbasura->dia=='20:01' ||
             $horariosbasura->dia=='20:02' ||
             $horariosbasura->dia=='20:03' ||
             $horariosbasura->dia=='20:04' ||
             $horariosbasura->dia=='20:05' ||
             $horariosbasura->dia=='20:06' ||
             $horariosbasura->dia=='20:07' ||
             $horariosbasura->dia=='20:08' ||
             $horariosbasura->dia=='20:09' ||
             $horariosbasura->dia=='20:10' ||
             $horariosbasura->dia=='20:11' ||
             $horariosbasura->dia=='20:12' ||
             $horariosbasura->dia=='20:13' ||
             $horariosbasura->dia=='20:14' ||
             $horariosbasura->dia=='20:15' ||
             $horariosbasura->dia=='20:16' ||
             $horariosbasura->dia=='20:17' ||
             $horariosbasura->dia=='20:18' ||
             $horariosbasura->dia=='20:19' ||
             $horariosbasura->dia=='20:20' ||
             $horariosbasura->dia=='20:21' ||
             $horariosbasura->dia=='20:22' ||
             $horariosbasura->dia=='20:23' ||
             $horariosbasura->dia=='20:24' ||
             $horariosbasura->dia=='20:25' ||
             $horariosbasura->dia=='20:26' ||
             $horariosbasura->dia=='20:27' ||
             $horariosbasura->dia=='20:28' ||
             $horariosbasura->dia=='20:29' ||
             $horariosbasura->dia=='20:30' || 
             $horariosbasura->dia=='20:31' ||
             $horariosbasura->dia=='20:32' ||
             $horariosbasura->dia=='20:33' ||
             $horariosbasura->dia=='20:34' ||
             $horariosbasura->dia=='20:35' ||
             $horariosbasura->dia=='20:36' ||
             $horariosbasura->dia=='20:37' ||
             $horariosbasura->dia=='20:38' ||
             $horariosbasura->dia=='20:39' ||
             $horariosbasura->dia=='20:40' ||
             $horariosbasura->dia=='20:41' ||
             $horariosbasura->dia=='20:42' ||
             $horariosbasura->dia=='20:43' ||
             $horariosbasura->dia=='20:44' ||
             $horariosbasura->dia=='20:45' ||
             $horariosbasura->dia=='20:46' ||
             $horariosbasura->dia=='20:47' ||
             $horariosbasura->dia=='20:48' ||
             $horariosbasura->dia=='20:49' ||
             $horariosbasura->dia=='20:50' ||
             $horariosbasura->dia=='20:51' ||
             $horariosbasura->dia=='20:52' ||
             $horariosbasura->dia=='20:53' ||
             $horariosbasura->dia=='20:54' ||
             $horariosbasura->dia=='20:55' ||
             $horariosbasura->dia=='20:56' ||
             $horariosbasura->dia=='20:57' ||
             $horariosbasura->dia=='20:58' ||
             $horariosbasura->dia=='20:59' ||

             $horariosbasura->dia=='21:00' ||
             $horariosbasura->dia=='21:01' ||
             $horariosbasura->dia=='21:02' ||
             $horariosbasura->dia=='21:03' ||
             $horariosbasura->dia=='21:04' ||
             $horariosbasura->dia=='21:05' ||
             $horariosbasura->dia=='21:06' ||
             $horariosbasura->dia=='21:07' ||
             $horariosbasura->dia=='21:08' ||
             $horariosbasura->dia=='21:09' ||
             $horariosbasura->dia=='21:10' ||
             $horariosbasura->dia=='21:11' ||
             $horariosbasura->dia=='21:12' ||
             $horariosbasura->dia=='21:13' ||
             $horariosbasura->dia=='21:14' ||
             $horariosbasura->dia=='21:15' ||
             $horariosbasura->dia=='21:16' ||
             $horariosbasura->dia=='21:17' ||
             $horariosbasura->dia=='21:18' ||
             $horariosbasura->dia=='21:19' ||
             $horariosbasura->dia=='21:20' ||
             $horariosbasura->dia=='21:21' ||
             $horariosbasura->dia=='21:22' ||
             $horariosbasura->dia=='21:23' ||
             $horariosbasura->dia=='21:24' ||
             $horariosbasura->dia=='21:25' ||
             $horariosbasura->dia=='21:26' ||
             $horariosbasura->dia=='21:27' ||
             $horariosbasura->dia=='21:28' ||
             $horariosbasura->dia=='21:29' ||
             $horariosbasura->dia=='21:30' || 
             $horariosbasura->dia=='21:31' ||
             $horariosbasura->dia=='21:32' ||
             $horariosbasura->dia=='21:33' ||
             $horariosbasura->dia=='21:34' ||
             $horariosbasura->dia=='21:35' ||
             $horariosbasura->dia=='21:36' ||
             $horariosbasura->dia=='21:37' ||
             $horariosbasura->dia=='21:38' ||
             $horariosbasura->dia=='21:39' ||
             $horariosbasura->dia=='21:40' ||
             $horariosbasura->dia=='21:41' ||
             $horariosbasura->dia=='21:42' ||
             $horariosbasura->dia=='21:43' ||
             $horariosbasura->dia=='21:44' ||
             $horariosbasura->dia=='21:45' ||
             $horariosbasura->dia=='21:46' ||
             $horariosbasura->dia=='21:47' ||
             $horariosbasura->dia=='21:48' ||
             $horariosbasura->dia=='21:49' ||
             $horariosbasura->dia=='21:50' ||
             $horariosbasura->dia=='21:51' ||
             $horariosbasura->dia=='21:52' ||
             $horariosbasura->dia=='21:53' ||
             $horariosbasura->dia=='21:54' ||
             $horariosbasura->dia=='21:55' ||
             $horariosbasura->dia=='21:56' ||
             $horariosbasura->dia=='21:57' ||
             $horariosbasura->dia=='21:58' ||
             $horariosbasura->dia=='21:59' ||

             $horariosbasura->dia=='22:00' ||
             $horariosbasura->dia=='22:01' ||
             $horariosbasura->dia=='22:02' ||
             $horariosbasura->dia=='22:03' ||
             $horariosbasura->dia=='22:04' ||
             $horariosbasura->dia=='22:05' ||
             $horariosbasura->dia=='22:06' ||
             $horariosbasura->dia=='22:07' ||
             $horariosbasura->dia=='22:08' ||
             $horariosbasura->dia=='22:09' ||
             $horariosbasura->dia=='22:10' ||
             $horariosbasura->dia=='22:11' ||
             $horariosbasura->dia=='22:12' ||
             $horariosbasura->dia=='22:13' ||
             $horariosbasura->dia=='22:14' ||
             $horariosbasura->dia=='22:15' ||
             $horariosbasura->dia=='22:16' ||
             $horariosbasura->dia=='22:17' ||
             $horariosbasura->dia=='22:18' ||
             $horariosbasura->dia=='22:19' ||
             $horariosbasura->dia=='22:20' ||
             $horariosbasura->dia=='22:21' ||
             $horariosbasura->dia=='22:22' ||
             $horariosbasura->dia=='22:23' ||
             $horariosbasura->dia=='22:24' ||
             $horariosbasura->dia=='22:25' ||
             $horariosbasura->dia=='22:26' ||
             $horariosbasura->dia=='22:27' ||
             $horariosbasura->dia=='22:28' ||
             $horariosbasura->dia=='22:29' ||
             $horariosbasura->dia=='22:30' || 
             $horariosbasura->dia=='22:31' ||
             $horariosbasura->dia=='22:32' ||
             $horariosbasura->dia=='22:33' ||
             $horariosbasura->dia=='22:34' ||
             $horariosbasura->dia=='22:35' ||
             $horariosbasura->dia=='22:36' ||
             $horariosbasura->dia=='22:37' ||
             $horariosbasura->dia=='22:38' ||
             $horariosbasura->dia=='22:39' ||
             $horariosbasura->dia=='22:40' ||
             $horariosbasura->dia=='22:41' ||
             $horariosbasura->dia=='22:42' ||
             $horariosbasura->dia=='22:43' ||
             $horariosbasura->dia=='22:44' ||
             $horariosbasura->dia=='22:45' ||
             $horariosbasura->dia=='22:46' ||
             $horariosbasura->dia=='22:47' ||
             $horariosbasura->dia=='22:48' ||
             $horariosbasura->dia=='22:49' ||
             $horariosbasura->dia=='22:50' ||
             $horariosbasura->dia=='22:51' ||
             $horariosbasura->dia=='22:52' ||
             $horariosbasura->dia=='22:53' ||
             $horariosbasura->dia=='22:54' ||
             $horariosbasura->dia=='22:55' ||
             $horariosbasura->dia=='22:56' ||
             $horariosbasura->dia=='22:57' ||
             $horariosbasura->dia=='22:58' ||
             $horariosbasura->dia=='22:59' ||

             $horariosbasura->dia=='23:00' ||
             $horariosbasura->dia=='23:01' ||
             $horariosbasura->dia=='23:02' ||
             $horariosbasura->dia=='23:03' ||
             $horariosbasura->dia=='23:04' ||
             $horariosbasura->dia=='23:05' ||
             $horariosbasura->dia=='23:06' ||
             $horariosbasura->dia=='23:07' ||
             $horariosbasura->dia=='23:08' ||
             $horariosbasura->dia=='23:09' ||
             $horariosbasura->dia=='23:10' ||
             $horariosbasura->dia=='23:11' ||
             $horariosbasura->dia=='23:12' ||
             $horariosbasura->dia=='23:13' ||
             $horariosbasura->dia=='23:14' ||
             $horariosbasura->dia=='23:15' ||
             $horariosbasura->dia=='23:16' ||
             $horariosbasura->dia=='23:17' ||
             $horariosbasura->dia=='23:18' ||
             $horariosbasura->dia=='23:19' ||
             $horariosbasura->dia=='23:20' ||
             $horariosbasura->dia=='23:21' ||
             $horariosbasura->dia=='23:22' ||
             $horariosbasura->dia=='23:23' ||
             $horariosbasura->dia=='23:24' ||
             $horariosbasura->dia=='23:25' ||
             $horariosbasura->dia=='23:26' ||
             $horariosbasura->dia=='23:27' ||
             $horariosbasura->dia=='23:28' ||
             $horariosbasura->dia=='23:29' ||
             $horariosbasura->dia=='23:30' || 
             $horariosbasura->dia=='23:31' ||
             $horariosbasura->dia=='23:32' ||
             $horariosbasura->dia=='23:33' ||
             $horariosbasura->dia=='23:34' ||
             $horariosbasura->dia=='23:35' ||
             $horariosbasura->dia=='23:36' ||
             $horariosbasura->dia=='23:37' ||
             $horariosbasura->dia=='23:38' ||
             $horariosbasura->dia=='23:39' ||
             $horariosbasura->dia=='23:40' ||
             $horariosbasura->dia=='23:41' ||
             $horariosbasura->dia=='23:42' ||
             $horariosbasura->dia=='23:43' ||
             $horariosbasura->dia=='23:44' ||
             $horariosbasura->dia=='23:45' ||
             $horariosbasura->dia=='23:46' ||
             $horariosbasura->dia=='23:47' ||
             $horariosbasura->dia=='23:48' ||
             $horariosbasura->dia=='23:49' ||
             $horariosbasura->dia=='23:50' ||
             $horariosbasura->dia=='23:51' ||
             $horariosbasura->dia=='23:52' ||
             $horariosbasura->dia=='23:53' ||
             $horariosbasura->dia=='23:54' ||
             $horariosbasura->dia=='23:55' ||
             $horariosbasura->dia=='23:56' ||
             $horariosbasura->dia=='23:57' ||
             $horariosbasura->dia=='23:58' ||
             $horariosbasura->dia=='23:59' ||
             $horariosbasura->dia=='00:00'
)
              <td><span class="badge badge-dark">Noche</span></td>
             @endif

        </tr>
        @endif
       @endforeach
    </tbody>

</table>

                                    </div>
                                </div>
                         <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                              </div> 
        </div>
      </div>
      
      
      
      <br>
      
       <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Horarios de limpieza:</p>
          <img src="https://www.mypropertyadmin.com/imagenes_property/limpieza.png" alt="Forest" style="width:100%;">
           @foreach($horarioslimpiezas as $horarioslimpieza)
        @if ( Auth::user()->urbanizacion==$horarioslimpieza->urbanizacion)
          <p><strong>{{$horarioslimpieza->hora}}</strong></p>
          <p>{{$horarioslimpieza->dia}}</p>
          @endif
          @endforeach
          @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                     <div class="w3-row w3-opacity">
            <div class="w3-half">
             <a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModallimpieza" ><i class="fa fa-eye"></i></a>
            </div>
            <div class="w3-half">
              <a href="{{url('/horarios_limpiezas')}}" class="w3-button w3-block w3-blue w3-section" ><i class="fa fa-cogs"></i></a>
            </div>
          </div>
          @else 
          <p><a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModallimpieza" ><i class="fa fa-eye"></i></a></p>
                      @endif
                      <div class="modal fade" id="myModallimpieza">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                  <div class="modal-header">
                                   <h4 class="modal-title">Panel de horarios de limpieza</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="row justify-content-center">
                                    <div class="modal-body">
                                      @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/horarios_limpiezas')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
                                    <div class="col-md-12">
                                      <div class="card">
               
                                       <table class="table table-light">

    <thead class='table-secondary'>
        <tr>
           <th>#</th>   
           <th>Hora</th>    
           <th>Dia</th>
           <th>Estado</th>  
           


        </tr>

    </thead>

    <tbody>
        @foreach($horarioslimpiezas as $horarioslimpieza)
        @if ( Auth::user()->urbanizacion==$horarioslimpieza->urbanizacion)
        <tr>
             <td>{{$loop->iteration}}</td>
             <td>{{$horarioslimpieza->dia}}</td>
             <td>{{$horarioslimpieza->hora}}</td>
            @if($horarioslimpieza->dia=='07:00' ||
             $horarioslimpieza->dia=='07:01' ||
             $horarioslimpieza->dia=='07:02' ||
             $horarioslimpieza->dia=='07:03' ||
             $horarioslimpieza->dia=='07:04' ||
             $horarioslimpieza->dia=='07:05' ||
             $horarioslimpieza->dia=='07:06' ||
             $horarioslimpieza->dia=='07:07' ||
             $horarioslimpieza->dia=='07:08' ||
             $horarioslimpieza->dia=='07:09' ||
             $horarioslimpieza->dia=='07:10' ||
             $horarioslimpieza->dia=='07:11' ||
             $horarioslimpieza->dia=='07:12' ||
             $horarioslimpieza->dia=='07:13' ||
             $horarioslimpieza->dia=='07:14' ||
             $horarioslimpieza->dia=='07:15' ||
             $horarioslimpieza->dia=='07:16' ||
             $horarioslimpieza->dia=='07:17' ||
             $horarioslimpieza->dia=='07:18' ||
             $horarioslimpieza->dia=='07:19' ||
             $horarioslimpieza->dia=='07:20' ||
             $horarioslimpieza->dia=='07:21' ||
             $horarioslimpieza->dia=='07:22' ||
             $horarioslimpieza->dia=='07:23' ||
             $horarioslimpieza->dia=='07:24' ||
             $horarioslimpieza->dia=='07:25' ||
             $horarioslimpieza->dia=='07:26' ||
             $horarioslimpieza->dia=='07:27' ||
             $horarioslimpieza->dia=='07:28' ||
             $horarioslimpieza->dia=='07:29' ||
             $horarioslimpieza->dia=='07:30' || 
             $horarioslimpieza->dia=='07:31' ||
             $horarioslimpieza->dia=='07:32' ||
             $horarioslimpieza->dia=='07:33' ||
             $horarioslimpieza->dia=='07:34' ||
             $horarioslimpieza->dia=='07:35' ||
             $horarioslimpieza->dia=='07:36' ||
             $horarioslimpieza->dia=='07:37' ||
             $horarioslimpieza->dia=='07:38' ||
             $horarioslimpieza->dia=='07:39' ||
             $horarioslimpieza->dia=='07:40' ||
             $horarioslimpieza->dia=='07:41' ||
             $horarioslimpieza->dia=='07:42' ||
             $horarioslimpieza->dia=='07:43' ||
             $horarioslimpieza->dia=='07:44' ||
             $horarioslimpieza->dia=='07:45' ||
             $horarioslimpieza->dia=='07:46' ||
             $horarioslimpieza->dia=='07:47' ||
             $horarioslimpieza->dia=='07:48' ||
             $horarioslimpieza->dia=='07:49' ||
             $horarioslimpieza->dia=='07:50' ||
             $horarioslimpieza->dia=='07:51' ||
             $horarioslimpieza->dia=='07:52' ||
             $horarioslimpieza->dia=='07:53' ||
             $horarioslimpieza->dia=='07:54' ||
             $horarioslimpieza->dia=='07:55' ||
             $horarioslimpieza->dia=='07:56' ||
             $horarioslimpieza->dia=='07:57' ||
             $horarioslimpieza->dia=='07:58' ||
             $horarioslimpieza->dia=='07:59' ||

             $horarioslimpieza->dia=='08:00' ||
             $horarioslimpieza->dia=='08:01' ||
             $horarioslimpieza->dia=='08:02' ||
             $horarioslimpieza->dia=='08:03' ||
             $horarioslimpieza->dia=='08:04' ||
             $horarioslimpieza->dia=='08:05' ||
             $horarioslimpieza->dia=='08:06' ||
             $horarioslimpieza->dia=='08:07' ||
             $horarioslimpieza->dia=='08:08' ||
             $horarioslimpieza->dia=='08:09' ||
             $horarioslimpieza->dia=='08:10' ||
             $horarioslimpieza->dia=='08:11' ||
             $horarioslimpieza->dia=='08:12' ||
             $horarioslimpieza->dia=='08:13' ||
             $horarioslimpieza->dia=='08:14' ||
             $horarioslimpieza->dia=='08:15' ||
             $horarioslimpieza->dia=='08:16' ||
             $horarioslimpieza->dia=='08:17' ||
             $horarioslimpieza->dia=='08:18' ||
             $horarioslimpieza->dia=='08:19' ||
             $horarioslimpieza->dia=='08:20' ||
             $horarioslimpieza->dia=='08:21' ||
             $horarioslimpieza->dia=='08:22' ||
             $horarioslimpieza->dia=='08:23' ||
             $horarioslimpieza->dia=='08:24' ||
             $horarioslimpieza->dia=='08:25' ||
             $horarioslimpieza->dia=='08:26' ||
             $horarioslimpieza->dia=='08:27' ||
             $horarioslimpieza->dia=='08:28' ||
             $horarioslimpieza->dia=='08:29' ||
             $horarioslimpieza->dia=='08:30' || 
             $horarioslimpieza->dia=='08:31' ||
             $horarioslimpieza->dia=='08:32' ||
             $horarioslimpieza->dia=='08:33' ||
             $horarioslimpieza->dia=='08:34' ||
             $horarioslimpieza->dia=='08:35' ||
             $horarioslimpieza->dia=='08:36' ||
             $horarioslimpieza->dia=='08:37' ||
             $horarioslimpieza->dia=='08:38' ||
             $horarioslimpieza->dia=='08:39' ||
             $horarioslimpieza->dia=='08:40' ||
             $horarioslimpieza->dia=='08:41' ||
             $horarioslimpieza->dia=='08:42' ||
             $horarioslimpieza->dia=='08:43' ||
             $horarioslimpieza->dia=='08:44' ||
             $horarioslimpieza->dia=='08:45' ||
             $horarioslimpieza->dia=='08:46' ||
             $horarioslimpieza->dia=='08:47' ||
             $horarioslimpieza->dia=='08:48' ||
             $horarioslimpieza->dia=='08:49' ||
             $horarioslimpieza->dia=='08:50' ||
             $horarioslimpieza->dia=='08:51' ||
             $horarioslimpieza->dia=='08:52' ||
             $horarioslimpieza->dia=='08:53' ||
             $horarioslimpieza->dia=='08:54' ||
             $horarioslimpieza->dia=='08:55' ||
             $horarioslimpieza->dia=='08:56' ||
             $horarioslimpieza->dia=='08:57' ||
             $horarioslimpieza->dia=='08:58' ||
             $horarioslimpieza->dia=='08:59' ||

             $horarioslimpieza->dia=='09:00' ||
             $horarioslimpieza->dia=='09:01' ||
             $horarioslimpieza->dia=='09:02' ||
             $horarioslimpieza->dia=='09:03' ||
             $horarioslimpieza->dia=='09:04' ||
             $horarioslimpieza->dia=='09:05' ||
             $horarioslimpieza->dia=='09:06' ||
             $horarioslimpieza->dia=='09:07' ||
             $horarioslimpieza->dia=='09:08' ||
             $horarioslimpieza->dia=='09:09' ||
             $horarioslimpieza->dia=='09:10' ||
             $horarioslimpieza->dia=='09:11' ||
             $horarioslimpieza->dia=='09:12' ||
             $horarioslimpieza->dia=='09:13' ||
             $horarioslimpieza->dia=='09:14' ||
             $horarioslimpieza->dia=='09:15' ||
             $horarioslimpieza->dia=='09:16' ||
             $horarioslimpieza->dia=='09:17' ||
             $horarioslimpieza->dia=='09:18' ||
             $horarioslimpieza->dia=='09:19' ||
             $horarioslimpieza->dia=='09:20' ||
             $horarioslimpieza->dia=='09:21' ||
             $horarioslimpieza->dia=='09:22' ||
             $horarioslimpieza->dia=='09:23' ||
             $horarioslimpieza->dia=='09:24' ||
             $horarioslimpieza->dia=='09:25' ||
             $horarioslimpieza->dia=='09:26' ||
             $horarioslimpieza->dia=='09:27' ||
             $horarioslimpieza->dia=='09:28' ||
             $horarioslimpieza->dia=='09:29' ||
             $horarioslimpieza->dia=='09:30' || 
             $horarioslimpieza->dia=='09:31' ||
             $horarioslimpieza->dia=='09:32' ||
             $horarioslimpieza->dia=='09:33' ||
             $horarioslimpieza->dia=='09:34' ||
             $horarioslimpieza->dia=='09:35' ||
             $horarioslimpieza->dia=='09:36' ||
             $horarioslimpieza->dia=='09:37' ||
             $horarioslimpieza->dia=='09:38' ||
             $horarioslimpieza->dia=='09:39' ||
             $horarioslimpieza->dia=='09:40' ||
             $horarioslimpieza->dia=='09:41' ||
             $horarioslimpieza->dia=='09:42' ||
             $horarioslimpieza->dia=='09:43' ||
             $horarioslimpieza->dia=='09:44' ||
             $horarioslimpieza->dia=='09:45' ||
             $horarioslimpieza->dia=='09:46' ||
             $horarioslimpieza->dia=='09:47' ||
             $horarioslimpieza->dia=='09:48' ||
             $horarioslimpieza->dia=='09:49' ||
             $horarioslimpieza->dia=='09:50' ||
             $horarioslimpieza->dia=='09:51' ||
             $horarioslimpieza->dia=='09:52' ||
             $horarioslimpieza->dia=='09:53' ||
             $horarioslimpieza->dia=='09:54' ||
             $horarioslimpieza->dia=='09:55' ||
             $horarioslimpieza->dia=='09:56' ||
             $horarioslimpieza->dia=='09:57' ||
             $horarioslimpieza->dia=='09:58' ||
             $horarioslimpieza->dia=='09:59' ||

             $horarioslimpieza->dia=='10:00' ||
             $horarioslimpieza->dia=='10:01' ||
             $horarioslimpieza->dia=='10:02' ||
             $horarioslimpieza->dia=='10:03' ||
             $horarioslimpieza->dia=='10:04' ||
             $horarioslimpieza->dia=='10:05' ||
             $horarioslimpieza->dia=='10:06' ||
             $horarioslimpieza->dia=='10:07' ||
             $horarioslimpieza->dia=='10:08' ||
             $horarioslimpieza->dia=='10:09' ||
             $horarioslimpieza->dia=='10:10' ||
             $horarioslimpieza->dia=='10:11' ||
             $horarioslimpieza->dia=='10:12' ||
             $horarioslimpieza->dia=='10:13' ||
             $horarioslimpieza->dia=='10:14' ||
             $horarioslimpieza->dia=='10:15' ||
             $horarioslimpieza->dia=='10:16' ||
             $horarioslimpieza->dia=='10:17' ||
             $horarioslimpieza->dia=='10:18' ||
             $horarioslimpieza->dia=='10:19' ||
             $horarioslimpieza->dia=='10:20' ||
             $horarioslimpieza->dia=='10:21' ||
             $horarioslimpieza->dia=='10:22' ||
             $horarioslimpieza->dia=='10:23' ||
             $horarioslimpieza->dia=='10:24' ||
             $horarioslimpieza->dia=='10:25' ||
             $horarioslimpieza->dia=='10:26' ||
             $horarioslimpieza->dia=='10:27' ||
             $horarioslimpieza->dia=='10:28' ||
             $horarioslimpieza->dia=='10:29' ||
             $horarioslimpieza->dia=='10:30' || 
             $horarioslimpieza->dia=='10:31' ||
             $horarioslimpieza->dia=='10:32' ||
             $horarioslimpieza->dia=='10:33' ||
             $horarioslimpieza->dia=='10:34' ||
             $horarioslimpieza->dia=='10:35' ||
             $horarioslimpieza->dia=='10:36' ||
             $horarioslimpieza->dia=='10:37' ||
             $horarioslimpieza->dia=='10:38' ||
             $horarioslimpieza->dia=='10:39' ||
             $horarioslimpieza->dia=='10:40' ||
             $horarioslimpieza->dia=='10:41' ||
             $horarioslimpieza->dia=='10:42' ||
             $horarioslimpieza->dia=='10:43' ||
             $horarioslimpieza->dia=='10:44' ||
             $horarioslimpieza->dia=='10:45' ||
             $horarioslimpieza->dia=='10:46' ||
             $horarioslimpieza->dia=='10:47' ||
             $horarioslimpieza->dia=='10:48' ||
             $horarioslimpieza->dia=='10:49' ||
             $horarioslimpieza->dia=='10:50' ||
             $horarioslimpieza->dia=='10:51' ||
             $horarioslimpieza->dia=='10:52' ||
             $horarioslimpieza->dia=='10:53' ||
             $horarioslimpieza->dia=='10:54' ||
             $horarioslimpieza->dia=='10:55' ||
             $horarioslimpieza->dia=='10:56' ||
             $horarioslimpieza->dia=='10:57' ||
             $horarioslimpieza->dia=='10:58' ||
             $horarioslimpieza->dia=='10:59' ||

             $horarioslimpieza->dia=='11:00' ||
             $horarioslimpieza->dia=='11:01' ||
             $horarioslimpieza->dia=='11:02' ||
             $horarioslimpieza->dia=='11:03' ||
             $horarioslimpieza->dia=='11:04' ||
             $horarioslimpieza->dia=='11:05' ||
             $horarioslimpieza->dia=='11:06' ||
             $horarioslimpieza->dia=='11:07' ||
             $horarioslimpieza->dia=='11:08' ||
             $horarioslimpieza->dia=='11:09' ||
             $horarioslimpieza->dia=='11:10' ||
             $horarioslimpieza->dia=='11:11' ||
             $horarioslimpieza->dia=='11:12' ||
             $horarioslimpieza->dia=='11:13' ||
             $horarioslimpieza->dia=='11:14' ||
             $horarioslimpieza->dia=='11:15' ||
             $horarioslimpieza->dia=='11:16' ||
             $horarioslimpieza->dia=='11:17' ||
             $horarioslimpieza->dia=='11:18' ||
             $horarioslimpieza->dia=='11:19' ||
             $horarioslimpieza->dia=='11:20' ||
             $horarioslimpieza->dia=='11:21' ||
             $horarioslimpieza->dia=='11:22' ||
             $horarioslimpieza->dia=='11:23' ||
             $horarioslimpieza->dia=='11:24' ||
             $horarioslimpieza->dia=='11:25' ||
             $horarioslimpieza->dia=='11:26' ||
             $horarioslimpieza->dia=='11:27' ||
             $horarioslimpieza->dia=='11:28' ||
             $horarioslimpieza->dia=='11:29' ||
             $horarioslimpieza->dia=='11:30' || 
             $horarioslimpieza->dia=='11:31' ||
             $horarioslimpieza->dia=='11:32' ||
             $horarioslimpieza->dia=='11:33' ||
             $horarioslimpieza->dia=='11:34' ||
             $horarioslimpieza->dia=='11:35' ||
             $horarioslimpieza->dia=='11:36' ||
             $horarioslimpieza->dia=='11:37' ||
             $horarioslimpieza->dia=='11:38' ||
             $horarioslimpieza->dia=='11:39' ||
             $horarioslimpieza->dia=='11:40' ||
             $horarioslimpieza->dia=='11:41' ||
             $horarioslimpieza->dia=='11:42' ||
             $horarioslimpieza->dia=='11:43' ||
             $horarioslimpieza->dia=='11:44' ||
             $horarioslimpieza->dia=='11:45' ||
             $horarioslimpieza->dia=='11:46' ||
             $horarioslimpieza->dia=='11:47' ||
             $horarioslimpieza->dia=='11:48' ||
             $horarioslimpieza->dia=='11:49' ||
             $horarioslimpieza->dia=='11:50' ||
             $horarioslimpieza->dia=='11:51' ||
             $horarioslimpieza->dia=='11:52' ||
             $horarioslimpieza->dia=='11:53' ||
             $horarioslimpieza->dia=='11:54' ||
             $horarioslimpieza->dia=='11:55' ||
             $horarioslimpieza->dia=='11:56' ||
             $horarioslimpieza->dia=='11:57' ||
             $horarioslimpieza->dia=='11:58' ||
             $horarioslimpieza->dia=='11:59' ||

             $horarioslimpieza->dia=='12:00' ||
             $horarioslimpieza->dia=='12:01' ||
             $horarioslimpieza->dia=='12:02' ||
             $horarioslimpieza->dia=='12:03' ||
             $horarioslimpieza->dia=='12:04' ||
             $horarioslimpieza->dia=='12:05' ||
             $horarioslimpieza->dia=='12:06' ||
             $horarioslimpieza->dia=='12:07' ||
             $horarioslimpieza->dia=='12:08' ||
             $horarioslimpieza->dia=='12:09' ||
             $horarioslimpieza->dia=='12:10' ||
             $horarioslimpieza->dia=='12:11' ||
             $horarioslimpieza->dia=='12:12' ||
             $horarioslimpieza->dia=='12:13' ||
             $horarioslimpieza->dia=='12:14' ||
             $horarioslimpieza->dia=='12:15' ||
             $horarioslimpieza->dia=='12:16' ||
             $horarioslimpieza->dia=='12:17' ||
             $horarioslimpieza->dia=='12:18' ||
             $horarioslimpieza->dia=='12:19' ||
             $horarioslimpieza->dia=='12:20' ||
             $horarioslimpieza->dia=='12:21' ||
             $horarioslimpieza->dia=='12:22' ||
             $horarioslimpieza->dia=='12:23' ||
             $horarioslimpieza->dia=='12:24' ||
             $horarioslimpieza->dia=='12:25' ||
             $horarioslimpieza->dia=='12:26' ||
             $horarioslimpieza->dia=='12:27' ||
             $horarioslimpieza->dia=='12:28' ||
             $horarioslimpieza->dia=='12:29' ||
             $horarioslimpieza->dia=='12:30' || 
             $horarioslimpieza->dia=='12:31' ||
             $horarioslimpieza->dia=='12:32' ||
             $horarioslimpieza->dia=='12:33' ||
             $horarioslimpieza->dia=='12:34' ||
             $horarioslimpieza->dia=='12:35' ||
             $horarioslimpieza->dia=='12:36' ||
             $horarioslimpieza->dia=='12:37' ||
             $horarioslimpieza->dia=='12:38' ||
             $horarioslimpieza->dia=='12:39' ||
             $horarioslimpieza->dia=='12:40' ||
             $horarioslimpieza->dia=='12:41' ||
             $horarioslimpieza->dia=='12:42' ||
             $horarioslimpieza->dia=='12:43' ||
             $horarioslimpieza->dia=='12:44' ||
             $horarioslimpieza->dia=='12:45' ||
             $horarioslimpieza->dia=='12:46' ||
             $horarioslimpieza->dia=='12:47' ||
             $horarioslimpieza->dia=='12:48' ||
             $horarioslimpieza->dia=='12:49' ||
             $horarioslimpieza->dia=='12:50' ||
             $horarioslimpieza->dia=='12:51' ||
             $horarioslimpieza->dia=='12:52' ||
             $horarioslimpieza->dia=='12:53' ||
             $horarioslimpieza->dia=='12:54' ||
             $horarioslimpieza->dia=='12:55' ||
             $horarioslimpieza->dia=='12:56' ||
             $horarioslimpieza->dia=='12:57' ||
             $horarioslimpieza->dia=='12:58' ||
             $horarioslimpieza->dia=='12:59'  )
              <td><span class="badge badge-primary">Mañana</span></td>
             @endif
             @if($horarioslimpieza->dia=='13:00' ||
             $horarioslimpieza->dia=='13:01' ||
             $horarioslimpieza->dia=='13:02' ||
             $horarioslimpieza->dia=='13:03' ||
             $horarioslimpieza->dia=='13:04' ||
             $horarioslimpieza->dia=='13:05' ||
             $horarioslimpieza->dia=='13:06' ||
             $horarioslimpieza->dia=='13:07' ||
             $horarioslimpieza->dia=='13:08' ||
             $horarioslimpieza->dia=='13:09' ||
             $horarioslimpieza->dia=='13:10' ||
             $horarioslimpieza->dia=='13:11' ||
             $horarioslimpieza->dia=='13:12' ||
             $horarioslimpieza->dia=='13:13' ||
             $horarioslimpieza->dia=='13:14' ||
             $horarioslimpieza->dia=='13:15' ||
             $horarioslimpieza->dia=='13:16' ||
             $horarioslimpieza->dia=='13:17' ||
             $horarioslimpieza->dia=='13:18' ||
             $horarioslimpieza->dia=='13:19' ||
             $horarioslimpieza->dia=='13:20' ||
             $horarioslimpieza->dia=='13:21' ||
             $horarioslimpieza->dia=='13:22' ||
             $horarioslimpieza->dia=='13:23' ||
             $horarioslimpieza->dia=='13:24' ||
             $horarioslimpieza->dia=='13:25' ||
             $horarioslimpieza->dia=='13:26' ||
             $horarioslimpieza->dia=='13:27' ||
             $horarioslimpieza->dia=='13:28' ||
             $horarioslimpieza->dia=='13:29' ||
             $horarioslimpieza->dia=='13:30' || 
             $horarioslimpieza->dia=='13:31' ||
             $horarioslimpieza->dia=='13:32' ||
             $horarioslimpieza->dia=='13:33' ||
             $horarioslimpieza->dia=='13:34' ||
             $horarioslimpieza->dia=='13:35' ||
             $horarioslimpieza->dia=='13:36' ||
             $horarioslimpieza->dia=='13:37' ||
             $horarioslimpieza->dia=='13:38' ||
             $horarioslimpieza->dia=='13:39' ||
             $horarioslimpieza->dia=='13:40' ||
             $horarioslimpieza->dia=='13:41' ||
             $horarioslimpieza->dia=='13:42' ||
             $horarioslimpieza->dia=='13:43' ||
             $horarioslimpieza->dia=='13:44' ||
             $horarioslimpieza->dia=='13:45' ||
             $horarioslimpieza->dia=='13:46' ||
             $horarioslimpieza->dia=='13:47' ||
             $horarioslimpieza->dia=='13:48' ||
             $horarioslimpieza->dia=='13:49' ||
             $horarioslimpieza->dia=='13:50' ||
             $horarioslimpieza->dia=='13:51' ||
             $horarioslimpieza->dia=='13:52' ||
             $horarioslimpieza->dia=='13:53' ||
             $horarioslimpieza->dia=='13:54' ||
             $horarioslimpieza->dia=='13:55' ||
             $horarioslimpieza->dia=='13:56' ||
             $horarioslimpieza->dia=='13:57' ||
             $horarioslimpieza->dia=='13:58' ||
             $horarioslimpieza->dia=='13:59' ||

             $horarioslimpieza->dia=='14:00' ||
             $horarioslimpieza->dia=='14:01' ||
             $horarioslimpieza->dia=='14:02' ||
             $horarioslimpieza->dia=='14:03' ||
             $horarioslimpieza->dia=='14:04' ||
             $horarioslimpieza->dia=='14:05' ||
             $horarioslimpieza->dia=='14:06' ||
             $horarioslimpieza->dia=='14:07' ||
             $horarioslimpieza->dia=='14:08' ||
             $horarioslimpieza->dia=='14:09' ||
             $horarioslimpieza->dia=='14:10' ||
             $horarioslimpieza->dia=='14:11' ||
             $horarioslimpieza->dia=='14:12' ||
             $horarioslimpieza->dia=='14:13' ||
             $horarioslimpieza->dia=='14:14' ||
             $horarioslimpieza->dia=='14:15' ||
             $horarioslimpieza->dia=='14:16' ||
             $horarioslimpieza->dia=='14:17' ||
             $horarioslimpieza->dia=='14:18' ||
             $horarioslimpieza->dia=='14:19' ||
             $horarioslimpieza->dia=='14:20' ||
             $horarioslimpieza->dia=='14:21' ||
             $horarioslimpieza->dia=='14:22' ||
             $horarioslimpieza->dia=='14:23' ||
             $horarioslimpieza->dia=='14:24' ||
             $horarioslimpieza->dia=='14:25' ||
             $horarioslimpieza->dia=='14:26' ||
             $horarioslimpieza->dia=='14:27' ||
             $horarioslimpieza->dia=='14:28' ||
             $horarioslimpieza->dia=='14:29' ||
             $horarioslimpieza->dia=='14:30' || 
             $horarioslimpieza->dia=='14:31' ||
             $horarioslimpieza->dia=='14:32' ||
             $horarioslimpieza->dia=='14:33' ||
             $horarioslimpieza->dia=='14:34' ||
             $horarioslimpieza->dia=='14:35' ||
             $horarioslimpieza->dia=='14:36' ||
             $horarioslimpieza->dia=='14:37' ||
             $horarioslimpieza->dia=='14:38' ||
             $horarioslimpieza->dia=='14:39' ||
             $horarioslimpieza->dia=='14:40' ||
             $horarioslimpieza->dia=='14:41' ||
             $horarioslimpieza->dia=='14:42' ||
             $horarioslimpieza->dia=='14:43' ||
             $horarioslimpieza->dia=='14:44' ||
             $horarioslimpieza->dia=='14:45' ||
             $horarioslimpieza->dia=='14:46' ||
             $horarioslimpieza->dia=='14:47' ||
             $horarioslimpieza->dia=='14:48' ||
             $horarioslimpieza->dia=='14:49' ||
             $horarioslimpieza->dia=='14:50' ||
             $horarioslimpieza->dia=='14:51' ||
             $horarioslimpieza->dia=='14:52' ||
             $horarioslimpieza->dia=='14:53' ||
             $horarioslimpieza->dia=='14:54' ||
             $horarioslimpieza->dia=='14:55' ||
             $horarioslimpieza->dia=='14:56' ||
             $horarioslimpieza->dia=='14:57' ||
             $horarioslimpieza->dia=='14:58' ||
             $horarioslimpieza->dia=='14:59' ||

             $horarioslimpieza->dia=='15:00' ||
             $horarioslimpieza->dia=='15:01' ||
             $horarioslimpieza->dia=='15:02' ||
             $horarioslimpieza->dia=='15:03' ||
             $horarioslimpieza->dia=='15:04' ||
             $horarioslimpieza->dia=='15:05' ||
             $horarioslimpieza->dia=='15:06' ||
             $horarioslimpieza->dia=='15:07' ||
             $horarioslimpieza->dia=='15:08' ||
             $horarioslimpieza->dia=='15:09' ||
             $horarioslimpieza->dia=='15:10' ||
             $horarioslimpieza->dia=='15:11' ||
             $horarioslimpieza->dia=='15:12' ||
             $horarioslimpieza->dia=='15:13' ||
             $horarioslimpieza->dia=='15:14' ||
             $horarioslimpieza->dia=='15:15' ||
             $horarioslimpieza->dia=='15:16' ||
             $horarioslimpieza->dia=='15:17' ||
             $horarioslimpieza->dia=='15:18' ||
             $horarioslimpieza->dia=='15:19' ||
             $horarioslimpieza->dia=='15:20' ||
             $horarioslimpieza->dia=='15:21' ||
             $horarioslimpieza->dia=='15:22' ||
             $horarioslimpieza->dia=='15:23' ||
             $horarioslimpieza->dia=='15:24' ||
             $horarioslimpieza->dia=='15:25' ||
             $horarioslimpieza->dia=='15:26' ||
             $horarioslimpieza->dia=='15:27' ||
             $horarioslimpieza->dia=='15:28' ||
             $horarioslimpieza->dia=='15:29' ||
             $horarioslimpieza->dia=='15:30' || 
             $horarioslimpieza->dia=='15:31' ||
             $horarioslimpieza->dia=='15:32' ||
             $horarioslimpieza->dia=='15:33' ||
             $horarioslimpieza->dia=='15:34' ||
             $horarioslimpieza->dia=='15:35' ||
             $horarioslimpieza->dia=='15:36' ||
             $horarioslimpieza->dia=='15:37' ||
             $horarioslimpieza->dia=='15:38' ||
             $horarioslimpieza->dia=='15:39' ||
             $horarioslimpieza->dia=='15:40' ||
             $horarioslimpieza->dia=='15:41' ||
             $horarioslimpieza->dia=='15:42' ||
             $horarioslimpieza->dia=='15:43' ||
             $horarioslimpieza->dia=='15:44' ||
             $horarioslimpieza->dia=='15:45' ||
             $horarioslimpieza->dia=='15:46' ||
             $horarioslimpieza->dia=='15:47' ||
             $horarioslimpieza->dia=='15:48' ||
             $horarioslimpieza->dia=='15:49' ||
             $horarioslimpieza->dia=='15:50' ||
             $horarioslimpieza->dia=='15:51' ||
             $horarioslimpieza->dia=='15:52' ||
             $horarioslimpieza->dia=='15:53' ||
             $horarioslimpieza->dia=='15:54' ||
             $horarioslimpieza->dia=='15:55' ||
             $horarioslimpieza->dia=='15:56' ||
             $horarioslimpieza->dia=='15:57' ||
             $horarioslimpieza->dia=='15:58' ||
             $horarioslimpieza->dia=='15:59' ||

             $horarioslimpieza->dia=='16:00' ||
             $horarioslimpieza->dia=='16:01' ||
             $horarioslimpieza->dia=='16:02' ||
             $horarioslimpieza->dia=='16:03' ||
             $horarioslimpieza->dia=='16:04' ||
             $horarioslimpieza->dia=='16:05' ||
             $horarioslimpieza->dia=='16:06' ||
             $horarioslimpieza->dia=='16:07' ||
             $horarioslimpieza->dia=='16:08' ||
             $horarioslimpieza->dia=='16:09' ||
             $horarioslimpieza->dia=='16:10' ||
             $horarioslimpieza->dia=='16:11' ||
             $horarioslimpieza->dia=='16:12' ||
             $horarioslimpieza->dia=='16:13' ||
             $horarioslimpieza->dia=='16:14' ||
             $horarioslimpieza->dia=='16:15' ||
             $horarioslimpieza->dia=='16:16' ||
             $horarioslimpieza->dia=='16:17' ||
             $horarioslimpieza->dia=='16:18' ||
             $horarioslimpieza->dia=='16:19' ||
             $horarioslimpieza->dia=='16:20' ||
             $horarioslimpieza->dia=='16:21' ||
             $horarioslimpieza->dia=='16:22' ||
             $horarioslimpieza->dia=='16:23' ||
             $horarioslimpieza->dia=='16:24' ||
             $horarioslimpieza->dia=='16:25' ||
             $horarioslimpieza->dia=='16:26' ||
             $horarioslimpieza->dia=='16:27' ||
             $horarioslimpieza->dia=='16:28' ||
             $horarioslimpieza->dia=='16:29' ||
             $horarioslimpieza->dia=='16:30' || 
             $horarioslimpieza->dia=='16:31' ||
             $horarioslimpieza->dia=='16:32' ||
             $horarioslimpieza->dia=='16:33' ||
             $horarioslimpieza->dia=='16:34' ||
             $horarioslimpieza->dia=='16:35' ||
             $horarioslimpieza->dia=='16:36' ||
             $horarioslimpieza->dia=='16:37' ||
             $horarioslimpieza->dia=='16:38' ||
             $horarioslimpieza->dia=='16:39' ||
             $horarioslimpieza->dia=='16:40' ||
             $horarioslimpieza->dia=='16:41' ||
             $horarioslimpieza->dia=='16:42' ||
             $horarioslimpieza->dia=='16:43' ||
             $horarioslimpieza->dia=='16:44' ||
             $horarioslimpieza->dia=='16:45' ||
             $horarioslimpieza->dia=='16:46' ||
             $horarioslimpieza->dia=='16:47' ||
             $horarioslimpieza->dia=='16:48' ||
             $horarioslimpieza->dia=='16:49' ||
             $horarioslimpieza->dia=='16:50' ||
             $horarioslimpieza->dia=='16:51' ||
             $horarioslimpieza->dia=='16:52' ||
             $horarioslimpieza->dia=='16:53' ||
             $horarioslimpieza->dia=='16:54' ||
             $horarioslimpieza->dia=='16:55' ||
             $horarioslimpieza->dia=='16:56' ||
             $horarioslimpieza->dia=='16:57' ||
             $horarioslimpieza->dia=='16:58' ||
             $horarioslimpieza->dia=='16:59' ||

             $horarioslimpieza->dia=='17:00' ||
             $horarioslimpieza->dia=='17:01' ||
             $horarioslimpieza->dia=='17:02' ||
             $horarioslimpieza->dia=='17:03' ||
             $horarioslimpieza->dia=='17:04' ||
             $horarioslimpieza->dia=='17:05' ||
             $horarioslimpieza->dia=='17:06' ||
             $horarioslimpieza->dia=='17:07' ||
             $horarioslimpieza->dia=='17:08' ||
             $horarioslimpieza->dia=='17:09' ||
             $horarioslimpieza->dia=='17:10' ||
             $horarioslimpieza->dia=='17:11' ||
             $horarioslimpieza->dia=='17:12' ||
             $horarioslimpieza->dia=='17:13' ||
             $horarioslimpieza->dia=='17:14' ||
             $horarioslimpieza->dia=='17:15' ||
             $horarioslimpieza->dia=='17:16' ||
             $horarioslimpieza->dia=='17:17' ||
             $horarioslimpieza->dia=='17:18' ||
             $horarioslimpieza->dia=='17:19' ||
             $horarioslimpieza->dia=='17:20' ||
             $horarioslimpieza->dia=='17:21' ||
             $horarioslimpieza->dia=='17:22' ||
             $horarioslimpieza->dia=='17:23' ||
             $horarioslimpieza->dia=='17:24' ||
             $horarioslimpieza->dia=='17:25' ||
             $horarioslimpieza->dia=='17:26' ||
             $horarioslimpieza->dia=='17:27' ||
             $horarioslimpieza->dia=='17:28' ||
             $horarioslimpieza->dia=='17:29' ||
             $horarioslimpieza->dia=='17:30' || 
             $horarioslimpieza->dia=='17:31' ||
             $horarioslimpieza->dia=='17:32' ||
             $horarioslimpieza->dia=='17:33' ||
             $horarioslimpieza->dia=='17:34' ||
             $horarioslimpieza->dia=='17:35' ||
             $horarioslimpieza->dia=='17:36' ||
             $horarioslimpieza->dia=='17:37' ||
             $horarioslimpieza->dia=='17:38' ||
             $horarioslimpieza->dia=='17:39' ||
             $horarioslimpieza->dia=='17:40' ||
             $horarioslimpieza->dia=='17:41' ||
             $horarioslimpieza->dia=='17:42' ||
             $horarioslimpieza->dia=='17:43' ||
             $horarioslimpieza->dia=='17:44' ||
             $horarioslimpieza->dia=='17:45' ||
             $horarioslimpieza->dia=='17:46' ||
             $horarioslimpieza->dia=='17:47' ||
             $horarioslimpieza->dia=='17:48' ||
             $horarioslimpieza->dia=='17:49' ||
             $horarioslimpieza->dia=='17:50' ||
             $horarioslimpieza->dia=='17:51' ||
             $horarioslimpieza->dia=='17:52' ||
             $horarioslimpieza->dia=='17:53' ||
             $horarioslimpieza->dia=='17:54' ||
             $horarioslimpieza->dia=='17:55' ||
             $horarioslimpieza->dia=='17:56' ||
             $horarioslimpieza->dia=='17:57' ||
             $horarioslimpieza->dia=='17:58' ||
             $horarioslimpieza->dia=='17:59' ||

             $horarioslimpieza->dia=='18:00' ||
             $horarioslimpieza->dia=='18:01' ||
             $horarioslimpieza->dia=='18:02' ||
             $horarioslimpieza->dia=='18:03' ||
             $horarioslimpieza->dia=='18:04' ||
             $horarioslimpieza->dia=='18:05' ||
             $horarioslimpieza->dia=='18:06' ||
             $horarioslimpieza->dia=='18:07' ||
             $horarioslimpieza->dia=='18:08' ||
             $horarioslimpieza->dia=='18:09' ||
             $horarioslimpieza->dia=='18:10' ||
             $horarioslimpieza->dia=='18:11' ||
             $horarioslimpieza->dia=='18:12' ||
             $horarioslimpieza->dia=='18:13' ||
             $horarioslimpieza->dia=='18:14' ||
             $horarioslimpieza->dia=='18:15' ||
             $horarioslimpieza->dia=='18:16' ||
             $horarioslimpieza->dia=='18:17' ||
             $horarioslimpieza->dia=='18:18' ||
             $horarioslimpieza->dia=='18:19' ||
             $horarioslimpieza->dia=='18:20' ||
             $horarioslimpieza->dia=='18:21' ||
             $horarioslimpieza->dia=='18:22' ||
             $horarioslimpieza->dia=='18:23' ||
             $horarioslimpieza->dia=='18:24' ||
             $horarioslimpieza->dia=='18:25' ||
             $horarioslimpieza->dia=='18:26' ||
             $horarioslimpieza->dia=='18:27' ||
             $horarioslimpieza->dia=='18:28' ||
             $horarioslimpieza->dia=='18:29' ||
             $horarioslimpieza->dia=='18:30' || 
             $horarioslimpieza->dia=='18:31' ||
             $horarioslimpieza->dia=='18:32' ||
             $horarioslimpieza->dia=='18:33' ||
             $horarioslimpieza->dia=='18:34' ||
             $horarioslimpieza->dia=='18:35' ||
             $horarioslimpieza->dia=='18:36' ||
             $horarioslimpieza->dia=='18:37' ||
             $horarioslimpieza->dia=='18:38' ||
             $horarioslimpieza->dia=='18:39' ||
             $horarioslimpieza->dia=='18:40' ||
             $horarioslimpieza->dia=='18:41' ||
             $horarioslimpieza->dia=='18:42' ||
             $horarioslimpieza->dia=='18:43' ||
             $horarioslimpieza->dia=='18:44' ||
             $horarioslimpieza->dia=='18:45' ||
             $horarioslimpieza->dia=='18:46' ||
             $horarioslimpieza->dia=='18:47' ||
             $horarioslimpieza->dia=='18:48' ||
             $horarioslimpieza->dia=='18:49' ||
             $horarioslimpieza->dia=='18:50' ||
             $horarioslimpieza->dia=='18:51' ||
             $horarioslimpieza->dia=='18:52' ||
             $horarioslimpieza->dia=='18:53' ||
             $horarioslimpieza->dia=='18:54' ||
             $horarioslimpieza->dia=='18:55' ||
             $horarioslimpieza->dia=='18:56' ||
             $horarioslimpieza->dia=='18:57' ||
             $horarioslimpieza->dia=='18:58' ||
             $horarioslimpieza->dia=='18:59' )
              <td><span class="badge badge-warning">Tarde</span></td>
             @endif
             @if($horarioslimpieza->dia=='19:00' ||
             $horarioslimpieza->dia=='19:01' ||
             $horarioslimpieza->dia=='19:02' ||
             $horarioslimpieza->dia=='19:03' ||
             $horarioslimpieza->dia=='19:04' ||
             $horarioslimpieza->dia=='19:05' ||
             $horarioslimpieza->dia=='19:06' ||
             $horarioslimpieza->dia=='19:07' ||
             $horarioslimpieza->dia=='19:08' ||
             $horarioslimpieza->dia=='19:09' ||
             $horarioslimpieza->dia=='19:10' ||
             $horarioslimpieza->dia=='19:11' ||
             $horarioslimpieza->dia=='19:12' ||
             $horarioslimpieza->dia=='19:13' ||
             $horarioslimpieza->dia=='19:14' ||
             $horarioslimpieza->dia=='19:15' ||
             $horarioslimpieza->dia=='19:16' ||
             $horarioslimpieza->dia=='19:17' ||
             $horarioslimpieza->dia=='19:18' ||
             $horarioslimpieza->dia=='19:19' ||
             $horarioslimpieza->dia=='19:20' ||
             $horarioslimpieza->dia=='19:21' ||
             $horarioslimpieza->dia=='19:22' ||
             $horarioslimpieza->dia=='19:23' ||
             $horarioslimpieza->dia=='19:24' ||
             $horarioslimpieza->dia=='19:25' ||
             $horarioslimpieza->dia=='19:26' ||
             $horarioslimpieza->dia=='19:27' ||
             $horarioslimpieza->dia=='19:28' ||
             $horarioslimpieza->dia=='19:29' ||
             $horarioslimpieza->dia=='19:30' || 
             $horarioslimpieza->dia=='19:31' ||
             $horarioslimpieza->dia=='19:32' ||
             $horarioslimpieza->dia=='19:33' ||
             $horarioslimpieza->dia=='19:34' ||
             $horarioslimpieza->dia=='19:35' ||
             $horarioslimpieza->dia=='19:36' ||
             $horarioslimpieza->dia=='19:37' ||
             $horarioslimpieza->dia=='19:38' ||
             $horarioslimpieza->dia=='19:39' ||
             $horarioslimpieza->dia=='19:40' ||
             $horarioslimpieza->dia=='19:41' ||
             $horarioslimpieza->dia=='19:42' ||
             $horarioslimpieza->dia=='19:43' ||
             $horarioslimpieza->dia=='19:44' ||
             $horarioslimpieza->dia=='19:45' ||
             $horarioslimpieza->dia=='19:46' ||
             $horarioslimpieza->dia=='19:47' ||
             $horarioslimpieza->dia=='19:48' ||
             $horarioslimpieza->dia=='19:49' ||
             $horarioslimpieza->dia=='19:50' ||
             $horarioslimpieza->dia=='19:51' ||
             $horarioslimpieza->dia=='19:52' ||
             $horarioslimpieza->dia=='19:53' ||
             $horarioslimpieza->dia=='19:54' ||
             $horarioslimpieza->dia=='19:55' ||
             $horarioslimpieza->dia=='19:56' ||
             $horarioslimpieza->dia=='19:57' ||
             $horarioslimpieza->dia=='19:58' ||
             $horarioslimpieza->dia=='19:59' ||  

             $horarioslimpieza->dia=='20:00' ||
             $horarioslimpieza->dia=='20:01' ||
             $horarioslimpieza->dia=='20:02' ||
             $horarioslimpieza->dia=='20:03' ||
             $horarioslimpieza->dia=='20:04' ||
             $horarioslimpieza->dia=='20:05' ||
             $horarioslimpieza->dia=='20:06' ||
             $horarioslimpieza->dia=='20:07' ||
             $horarioslimpieza->dia=='20:08' ||
             $horarioslimpieza->dia=='20:09' ||
             $horarioslimpieza->dia=='20:10' ||
             $horarioslimpieza->dia=='20:11' ||
             $horarioslimpieza->dia=='20:12' ||
             $horarioslimpieza->dia=='20:13' ||
             $horarioslimpieza->dia=='20:14' ||
             $horarioslimpieza->dia=='20:15' ||
             $horarioslimpieza->dia=='20:16' ||
             $horarioslimpieza->dia=='20:17' ||
             $horarioslimpieza->dia=='20:18' ||
             $horarioslimpieza->dia=='20:19' ||
             $horarioslimpieza->dia=='20:20' ||
             $horarioslimpieza->dia=='20:21' ||
             $horarioslimpieza->dia=='20:22' ||
             $horarioslimpieza->dia=='20:23' ||
             $horarioslimpieza->dia=='20:24' ||
             $horarioslimpieza->dia=='20:25' ||
             $horarioslimpieza->dia=='20:26' ||
             $horarioslimpieza->dia=='20:27' ||
             $horarioslimpieza->dia=='20:28' ||
             $horarioslimpieza->dia=='20:29' ||
             $horarioslimpieza->dia=='20:30' || 
             $horarioslimpieza->dia=='20:31' ||
             $horarioslimpieza->dia=='20:32' ||
             $horarioslimpieza->dia=='20:33' ||
             $horarioslimpieza->dia=='20:34' ||
             $horarioslimpieza->dia=='20:35' ||
             $horarioslimpieza->dia=='20:36' ||
             $horarioslimpieza->dia=='20:37' ||
             $horarioslimpieza->dia=='20:38' ||
             $horarioslimpieza->dia=='20:39' ||
             $horarioslimpieza->dia=='20:40' ||
             $horarioslimpieza->dia=='20:41' ||
             $horarioslimpieza->dia=='20:42' ||
             $horarioslimpieza->dia=='20:43' ||
             $horarioslimpieza->dia=='20:44' ||
             $horarioslimpieza->dia=='20:45' ||
             $horarioslimpieza->dia=='20:46' ||
             $horarioslimpieza->dia=='20:47' ||
             $horarioslimpieza->dia=='20:48' ||
             $horarioslimpieza->dia=='20:49' ||
             $horarioslimpieza->dia=='20:50' ||
             $horarioslimpieza->dia=='20:51' ||
             $horarioslimpieza->dia=='20:52' ||
             $horarioslimpieza->dia=='20:53' ||
             $horarioslimpieza->dia=='20:54' ||
             $horarioslimpieza->dia=='20:55' ||
             $horarioslimpieza->dia=='20:56' ||
             $horarioslimpieza->dia=='20:57' ||
             $horarioslimpieza->dia=='20:58' ||
             $horarioslimpieza->dia=='20:59' ||

             $horarioslimpieza->dia=='21:00' ||
             $horarioslimpieza->dia=='21:01' ||
             $horarioslimpieza->dia=='21:02' ||
             $horarioslimpieza->dia=='21:03' ||
             $horarioslimpieza->dia=='21:04' ||
             $horarioslimpieza->dia=='21:05' ||
             $horarioslimpieza->dia=='21:06' ||
             $horarioslimpieza->dia=='21:07' ||
             $horarioslimpieza->dia=='21:08' ||
             $horarioslimpieza->dia=='21:09' ||
             $horarioslimpieza->dia=='21:10' ||
             $horarioslimpieza->dia=='21:11' ||
             $horarioslimpieza->dia=='21:12' ||
             $horarioslimpieza->dia=='21:13' ||
             $horarioslimpieza->dia=='21:14' ||
             $horarioslimpieza->dia=='21:15' ||
             $horarioslimpieza->dia=='21:16' ||
             $horarioslimpieza->dia=='21:17' ||
             $horarioslimpieza->dia=='21:18' ||
             $horarioslimpieza->dia=='21:19' ||
             $horarioslimpieza->dia=='21:20' ||
             $horarioslimpieza->dia=='21:21' ||
             $horarioslimpieza->dia=='21:22' ||
             $horarioslimpieza->dia=='21:23' ||
             $horarioslimpieza->dia=='21:24' ||
             $horarioslimpieza->dia=='21:25' ||
             $horarioslimpieza->dia=='21:26' ||
             $horarioslimpieza->dia=='21:27' ||
             $horarioslimpieza->dia=='21:28' ||
             $horarioslimpieza->dia=='21:29' ||
             $horarioslimpieza->dia=='21:30' || 
             $horarioslimpieza->dia=='21:31' ||
             $horarioslimpieza->dia=='21:32' ||
             $horarioslimpieza->dia=='21:33' ||
             $horarioslimpieza->dia=='21:34' ||
             $horarioslimpieza->dia=='21:35' ||
             $horarioslimpieza->dia=='21:36' ||
             $horarioslimpieza->dia=='21:37' ||
             $horarioslimpieza->dia=='21:38' ||
             $horarioslimpieza->dia=='21:39' ||
             $horarioslimpieza->dia=='21:40' ||
             $horarioslimpieza->dia=='21:41' ||
             $horarioslimpieza->dia=='21:42' ||
             $horarioslimpieza->dia=='21:43' ||
             $horarioslimpieza->dia=='21:44' ||
             $horarioslimpieza->dia=='21:45' ||
             $horarioslimpieza->dia=='21:46' ||
             $horarioslimpieza->dia=='21:47' ||
             $horarioslimpieza->dia=='21:48' ||
             $horarioslimpieza->dia=='21:49' ||
             $horarioslimpieza->dia=='21:50' ||
             $horarioslimpieza->dia=='21:51' ||
             $horarioslimpieza->dia=='21:52' ||
             $horarioslimpieza->dia=='21:53' ||
             $horarioslimpieza->dia=='21:54' ||
             $horarioslimpieza->dia=='21:55' ||
             $horarioslimpieza->dia=='21:56' ||
             $horarioslimpieza->dia=='21:57' ||
             $horarioslimpieza->dia=='21:58' ||
             $horarioslimpieza->dia=='21:59' ||

             $horarioslimpieza->dia=='22:00' ||
             $horarioslimpieza->dia=='22:01' ||
             $horarioslimpieza->dia=='22:02' ||
             $horarioslimpieza->dia=='22:03' ||
             $horarioslimpieza->dia=='22:04' ||
             $horarioslimpieza->dia=='22:05' ||
             $horarioslimpieza->dia=='22:06' ||
             $horarioslimpieza->dia=='22:07' ||
             $horarioslimpieza->dia=='22:08' ||
             $horarioslimpieza->dia=='22:09' ||
             $horarioslimpieza->dia=='22:10' ||
             $horarioslimpieza->dia=='22:11' ||
             $horarioslimpieza->dia=='22:12' ||
             $horarioslimpieza->dia=='22:13' ||
             $horarioslimpieza->dia=='22:14' ||
             $horarioslimpieza->dia=='22:15' ||
             $horarioslimpieza->dia=='22:16' ||
             $horarioslimpieza->dia=='22:17' ||
             $horarioslimpieza->dia=='22:18' ||
             $horarioslimpieza->dia=='22:19' ||
             $horarioslimpieza->dia=='22:20' ||
             $horarioslimpieza->dia=='22:21' ||
             $horarioslimpieza->dia=='22:22' ||
             $horarioslimpieza->dia=='22:23' ||
             $horarioslimpieza->dia=='22:24' ||
             $horarioslimpieza->dia=='22:25' ||
             $horarioslimpieza->dia=='22:26' ||
             $horarioslimpieza->dia=='22:27' ||
             $horarioslimpieza->dia=='22:28' ||
             $horarioslimpieza->dia=='22:29' ||
             $horarioslimpieza->dia=='22:30' || 
             $horarioslimpieza->dia=='22:31' ||
             $horarioslimpieza->dia=='22:32' ||
             $horarioslimpieza->dia=='22:33' ||
             $horarioslimpieza->dia=='22:34' ||
             $horarioslimpieza->dia=='22:35' ||
             $horarioslimpieza->dia=='22:36' ||
             $horarioslimpieza->dia=='22:37' ||
             $horarioslimpieza->dia=='22:38' ||
             $horarioslimpieza->dia=='22:39' ||
             $horarioslimpieza->dia=='22:40' ||
             $horarioslimpieza->dia=='22:41' ||
             $horarioslimpieza->dia=='22:42' ||
             $horarioslimpieza->dia=='22:43' ||
             $horarioslimpieza->dia=='22:44' ||
             $horarioslimpieza->dia=='22:45' ||
             $horarioslimpieza->dia=='22:46' ||
             $horarioslimpieza->dia=='22:47' ||
             $horarioslimpieza->dia=='22:48' ||
             $horarioslimpieza->dia=='22:49' ||
             $horarioslimpieza->dia=='22:50' ||
             $horarioslimpieza->dia=='22:51' ||
             $horarioslimpieza->dia=='22:52' ||
             $horarioslimpieza->dia=='22:53' ||
             $horarioslimpieza->dia=='22:54' ||
             $horarioslimpieza->dia=='22:55' ||
             $horarioslimpieza->dia=='22:56' ||
             $horarioslimpieza->dia=='22:57' ||
             $horarioslimpieza->dia=='22:58' ||
             $horarioslimpieza->dia=='22:59' ||

             $horarioslimpieza->dia=='23:00' ||
             $horarioslimpieza->dia=='23:01' ||
             $horarioslimpieza->dia=='23:02' ||
             $horarioslimpieza->dia=='23:03' ||
             $horarioslimpieza->dia=='23:04' ||
             $horarioslimpieza->dia=='23:05' ||
             $horarioslimpieza->dia=='23:06' ||
             $horarioslimpieza->dia=='23:07' ||
             $horarioslimpieza->dia=='23:08' ||
             $horarioslimpieza->dia=='23:09' ||
             $horarioslimpieza->dia=='23:10' ||
             $horarioslimpieza->dia=='23:11' ||
             $horarioslimpieza->dia=='23:12' ||
             $horarioslimpieza->dia=='23:13' ||
             $horarioslimpieza->dia=='23:14' ||
             $horarioslimpieza->dia=='23:15' ||
             $horarioslimpieza->dia=='23:16' ||
             $horarioslimpieza->dia=='23:17' ||
             $horarioslimpieza->dia=='23:18' ||
             $horarioslimpieza->dia=='23:19' ||
             $horarioslimpieza->dia=='23:20' ||
             $horarioslimpieza->dia=='23:21' ||
             $horarioslimpieza->dia=='23:22' ||
             $horarioslimpieza->dia=='23:23' ||
             $horarioslimpieza->dia=='23:24' ||
             $horarioslimpieza->dia=='23:25' ||
             $horarioslimpieza->dia=='23:26' ||
             $horarioslimpieza->dia=='23:27' ||
             $horarioslimpieza->dia=='23:28' ||
             $horarioslimpieza->dia=='23:29' ||
             $horarioslimpieza->dia=='23:30' || 
             $horarioslimpieza->dia=='23:31' ||
             $horarioslimpieza->dia=='23:32' ||
             $horarioslimpieza->dia=='23:33' ||
             $horarioslimpieza->dia=='23:34' ||
             $horarioslimpieza->dia=='23:35' ||
             $horarioslimpieza->dia=='23:36' ||
             $horarioslimpieza->dia=='23:37' ||
             $horarioslimpieza->dia=='23:38' ||
             $horarioslimpieza->dia=='23:39' ||
             $horarioslimpieza->dia=='23:40' ||
             $horarioslimpieza->dia=='23:41' ||
             $horarioslimpieza->dia=='23:42' ||
             $horarioslimpieza->dia=='23:43' ||
             $horarioslimpieza->dia=='23:44' ||
             $horarioslimpieza->dia=='23:45' ||
             $horarioslimpieza->dia=='23:46' ||
             $horarioslimpieza->dia=='23:47' ||
             $horarioslimpieza->dia=='23:48' ||
             $horarioslimpieza->dia=='23:49' ||
             $horarioslimpieza->dia=='23:50' ||
             $horarioslimpieza->dia=='23:51' ||
             $horarioslimpieza->dia=='23:52' ||
             $horarioslimpieza->dia=='23:53' ||
             $horarioslimpieza->dia=='23:54' ||
             $horarioslimpieza->dia=='23:55' ||
             $horarioslimpieza->dia=='23:56' ||
             $horarioslimpieza->dia=='23:57' ||
             $horarioslimpieza->dia=='23:58' ||
             $horarioslimpieza->dia=='23:59' ||
             $horarioslimpieza->dia=='00:00')
              <td><span class="badge badge-dark">Noche</span></td>
             @endif

        </tr>
        @endif
       @endforeach
    </tbody>

</table>

                                    </div>
                                </div>
                         <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                              </div> 
        </div>
      </div>

      <br>

      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Horarios de reunion:</p>
          <img src="https://www.mypropertyadmin.com/imagenes_property/horarios.png" alt="Forest" style="width:100%;">
          @foreach($horariosreuniones as $horariosreunion)
        @if ( Auth::user()->urbanizacion==$horariosreunion->urbanizacion)
          <p><strong>{{$horariosreunion->hora}}</strong></p>
          <p>{{$horariosreunion->dia}}</p>
          @endif
          @endforeach
          @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                     <div class="w3-row w3-opacity">
            <div class="w3-half">
              <a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalreuniones" ><i class="fa fa-eye"></i></a>
            </div>
            <div class="w3-half">
              <a href="{{url('/horarios_reuniones')}}" class="w3-button w3-block w3-blue w3-section" ><i class="fa fa-cogs"></i></a>
            </div>
          </div>
          @else 
          <p><a href="" class="w3-button w3-block w3-green w3-section" data-toggle="modal" data-target="#myModalreuniones" ><i class="fa fa-eye"></i></a></p>
                      @endif
                      <div class="modal fade" id="myModalreuniones">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                              
                                <!-- Modal Header -->
                                  <div class="modal-header">
                                   <h4 class="modal-title">Panel de horarios de reuniones</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="row justify-content-center">
                                    <div class="modal-body">
                                      @if ( Auth::user()->tipo_persona=='Administrador urbanizacion' || Auth::user()->tipo_persona=='Desarrollador - Administrador')
                                                   <a href="{{url('/horarios_reuniones')}}" class="btn btn-info" ><i class="fa fa-cogs"></i></a>
                                                    </br>
                                                   </br>
                                  
                                       @endif
                                    <div class="col-md-12">
                                      <div class="card">
               
                                        <table class="table table-light">
    <thead class='table-secondary'>
        <tr>
           <th>#</th>   
           <th>Hora</th>    
           <th>Dia</th>  
           <th>Motivo</th>  
           <th>Estado</th> 


        </tr>

    </thead>

    <tbody>
        @foreach($horariosreuniones as $horariosreunion)
        @if ( Auth::user()->urbanizacion==$horariosreunion->urbanizacion)
        <tr>
             <td>{{$loop->iteration}}</td>
             <td>{{$horariosreunion->dia}}</td>
             <td>{{$horariosreunion->hora}}</td>
             <td>{{$horariosreunion->motivo}}</td>
             @if($horariosreunion->dia=='07:00' ||
             $horariosreunion->dia=='07:01' ||
             $horariosreunion->dia=='07:02' ||
             $horariosreunion->dia=='07:03' ||
             $horariosreunion->dia=='07:04' ||
             $horariosreunion->dia=='07:05' ||
             $horariosreunion->dia=='07:06' ||
             $horariosreunion->dia=='07:07' ||
             $horariosreunion->dia=='07:08' ||
             $horariosreunion->dia=='07:09' ||
             $horariosreunion->dia=='07:10' ||
             $horariosreunion->dia=='07:11' ||
             $horariosreunion->dia=='07:12' ||
             $horariosreunion->dia=='07:13' ||
             $horariosreunion->dia=='07:14' ||
             $horariosreunion->dia=='07:15' ||
             $horariosreunion->dia=='07:16' ||
             $horariosreunion->dia=='07:17' ||
             $horariosreunion->dia=='07:18' ||
             $horariosreunion->dia=='07:19' ||
             $horariosreunion->dia=='07:20' ||
             $horariosreunion->dia=='07:21' ||
             $horariosreunion->dia=='07:22' ||
             $horariosreunion->dia=='07:23' ||
             $horariosreunion->dia=='07:24' ||
             $horariosreunion->dia=='07:25' ||
             $horariosreunion->dia=='07:26' ||
             $horariosreunion->dia=='07:27' ||
             $horariosreunion->dia=='07:28' ||
             $horariosreunion->dia=='07:29' ||
             $horariosreunion->dia=='07:30' || 
             $horariosreunion->dia=='07:31' ||
             $horariosreunion->dia=='07:32' ||
             $horariosreunion->dia=='07:33' ||
             $horariosreunion->dia=='07:34' ||
             $horariosreunion->dia=='07:35' ||
             $horariosreunion->dia=='07:36' ||
             $horariosreunion->dia=='07:37' ||
             $horariosreunion->dia=='07:38' ||
             $horariosreunion->dia=='07:39' ||
             $horariosreunion->dia=='07:40' ||
             $horariosreunion->dia=='07:41' ||
             $horariosreunion->dia=='07:42' ||
             $horariosreunion->dia=='07:43' ||
             $horariosreunion->dia=='07:44' ||
             $horariosreunion->dia=='07:45' ||
             $horariosreunion->dia=='07:46' ||
             $horariosreunion->dia=='07:47' ||
             $horariosreunion->dia=='07:48' ||
             $horariosreunion->dia=='07:49' ||
             $horariosreunion->dia=='07:50' ||
             $horariosreunion->dia=='07:51' ||
             $horariosreunion->dia=='07:52' ||
             $horariosreunion->dia=='07:53' ||
             $horariosreunion->dia=='07:54' ||
             $horariosreunion->dia=='07:55' ||
             $horariosreunion->dia=='07:56' ||
             $horariosreunion->dia=='07:57' ||
             $horariosreunion->dia=='07:58' ||
             $horariosreunion->dia=='07:59' ||

             $horariosreunion->dia=='08:00' ||
             $horariosreunion->dia=='08:01' ||
             $horariosreunion->dia=='08:02' ||
             $horariosreunion->dia=='08:03' ||
             $horariosreunion->dia=='08:04' ||
             $horariosreunion->dia=='08:05' ||
             $horariosreunion->dia=='08:06' ||
             $horariosreunion->dia=='08:07' ||
             $horariosreunion->dia=='08:08' ||
             $horariosreunion->dia=='08:09' ||
             $horariosreunion->dia=='08:10' ||
             $horariosreunion->dia=='08:11' ||
             $horariosreunion->dia=='08:12' ||
             $horariosreunion->dia=='08:13' ||
             $horariosreunion->dia=='08:14' ||
             $horariosreunion->dia=='08:15' ||
             $horariosreunion->dia=='08:16' ||
             $horariosreunion->dia=='08:17' ||
             $horariosreunion->dia=='08:18' ||
             $horariosreunion->dia=='08:19' ||
             $horariosreunion->dia=='08:20' ||
             $horariosreunion->dia=='08:21' ||
             $horariosreunion->dia=='08:22' ||
             $horariosreunion->dia=='08:23' ||
             $horariosreunion->dia=='08:24' ||
             $horariosreunion->dia=='08:25' ||
             $horariosreunion->dia=='08:26' ||
             $horariosreunion->dia=='08:27' ||
             $horariosreunion->dia=='08:28' ||
             $horariosreunion->dia=='08:29' ||
             $horariosreunion->dia=='08:30' || 
             $horariosreunion->dia=='08:31' ||
             $horariosreunion->dia=='08:32' ||
             $horariosreunion->dia=='08:33' ||
             $horariosreunion->dia=='08:34' ||
             $horariosreunion->dia=='08:35' ||
             $horariosreunion->dia=='08:36' ||
             $horariosreunion->dia=='08:37' ||
             $horariosreunion->dia=='08:38' ||
             $horariosreunion->dia=='08:39' ||
             $horariosreunion->dia=='08:40' ||
             $horariosreunion->dia=='08:41' ||
             $horariosreunion->dia=='08:42' ||
             $horariosreunion->dia=='08:43' ||
             $horariosreunion->dia=='08:44' ||
             $horariosreunion->dia=='08:45' ||
             $horariosreunion->dia=='08:46' ||
             $horariosreunion->dia=='08:47' ||
             $horariosreunion->dia=='08:48' ||
             $horariosreunion->dia=='08:49' ||
             $horariosreunion->dia=='08:50' ||
             $horariosreunion->dia=='08:51' ||
             $horariosreunion->dia=='08:52' ||
             $horariosreunion->dia=='08:53' ||
             $horariosreunion->dia=='08:54' ||
             $horariosreunion->dia=='08:55' ||
             $horariosreunion->dia=='08:56' ||
             $horariosreunion->dia=='08:57' ||
             $horariosreunion->dia=='08:58' ||
             $horariosreunion->dia=='08:59' ||

             $horariosreunion->dia=='09:00' ||
             $horariosreunion->dia=='09:01' ||
             $horariosreunion->dia=='09:02' ||
             $horariosreunion->dia=='09:03' ||
             $horariosreunion->dia=='09:04' ||
             $horariosreunion->dia=='09:05' ||
             $horariosreunion->dia=='09:06' ||
             $horariosreunion->dia=='09:07' ||
             $horariosreunion->dia=='09:08' ||
             $horariosreunion->dia=='09:09' ||
             $horariosreunion->dia=='09:10' ||
             $horariosreunion->dia=='09:11' ||
             $horariosreunion->dia=='09:12' ||
             $horariosreunion->dia=='09:13' ||
             $horariosreunion->dia=='09:14' ||
             $horariosreunion->dia=='09:15' ||
             $horariosreunion->dia=='09:16' ||
             $horariosreunion->dia=='09:17' ||
             $horariosreunion->dia=='09:18' ||
             $horariosreunion->dia=='09:19' ||
             $horariosreunion->dia=='09:20' ||
             $horariosreunion->dia=='09:21' ||
             $horariosreunion->dia=='09:22' ||
             $horariosreunion->dia=='09:23' ||
             $horariosreunion->dia=='09:24' ||
             $horariosreunion->dia=='09:25' ||
             $horariosreunion->dia=='09:26' ||
             $horariosreunion->dia=='09:27' ||
             $horariosreunion->dia=='09:28' ||
             $horariosreunion->dia=='09:29' ||
             $horariosreunion->dia=='09:30' || 
             $horariosreunion->dia=='09:31' ||
             $horariosreunion->dia=='09:32' ||
             $horariosreunion->dia=='09:33' ||
             $horariosreunion->dia=='09:34' ||
             $horariosreunion->dia=='09:35' ||
             $horariosreunion->dia=='09:36' ||
             $horariosreunion->dia=='09:37' ||
             $horariosreunion->dia=='09:38' ||
             $horariosreunion->dia=='09:39' ||
             $horariosreunion->dia=='09:40' ||
             $horariosreunion->dia=='09:41' ||
             $horariosreunion->dia=='09:42' ||
             $horariosreunion->dia=='09:43' ||
             $horariosreunion->dia=='09:44' ||
             $horariosreunion->dia=='09:45' ||
             $horariosreunion->dia=='09:46' ||
             $horariosreunion->dia=='09:47' ||
             $horariosreunion->dia=='09:48' ||
             $horariosreunion->dia=='09:49' ||
             $horariosreunion->dia=='09:50' ||
             $horariosreunion->dia=='09:51' ||
             $horariosreunion->dia=='09:52' ||
             $horariosreunion->dia=='09:53' ||
             $horariosreunion->dia=='09:54' ||
             $horariosreunion->dia=='09:55' ||
             $horariosreunion->dia=='09:56' ||
             $horariosreunion->dia=='09:57' ||
             $horariosreunion->dia=='09:58' ||
             $horariosreunion->dia=='09:59' ||

             $horariosreunion->dia=='10:00' ||
             $horariosreunion->dia=='10:01' ||
             $horariosreunion->dia=='10:02' ||
             $horariosreunion->dia=='10:03' ||
             $horariosreunion->dia=='10:04' ||
             $horariosreunion->dia=='10:05' ||
             $horariosreunion->dia=='10:06' ||
             $horariosreunion->dia=='10:07' ||
             $horariosreunion->dia=='10:08' ||
             $horariosreunion->dia=='10:09' ||
             $horariosreunion->dia=='10:10' ||
             $horariosreunion->dia=='10:11' ||
             $horariosreunion->dia=='10:12' ||
             $horariosreunion->dia=='10:13' ||
             $horariosreunion->dia=='10:14' ||
             $horariosreunion->dia=='10:15' ||
             $horariosreunion->dia=='10:16' ||
             $horariosreunion->dia=='10:17' ||
             $horariosreunion->dia=='10:18' ||
             $horariosreunion->dia=='10:19' ||
             $horariosreunion->dia=='10:20' ||
             $horariosreunion->dia=='10:21' ||
             $horariosreunion->dia=='10:22' ||
             $horariosreunion->dia=='10:23' ||
             $horariosreunion->dia=='10:24' ||
             $horariosreunion->dia=='10:25' ||
             $horariosreunion->dia=='10:26' ||
             $horariosreunion->dia=='10:27' ||
             $horariosreunion->dia=='10:28' ||
             $horariosreunion->dia=='10:29' ||
             $horariosreunion->dia=='10:30' || 
             $horariosreunion->dia=='10:31' ||
             $horariosreunion->dia=='10:32' ||
             $horariosreunion->dia=='10:33' ||
             $horariosreunion->dia=='10:34' ||
             $horariosreunion->dia=='10:35' ||
             $horariosreunion->dia=='10:36' ||
             $horariosreunion->dia=='10:37' ||
             $horariosreunion->dia=='10:38' ||
             $horariosreunion->dia=='10:39' ||
             $horariosreunion->dia=='10:40' ||
             $horariosreunion->dia=='10:41' ||
             $horariosreunion->dia=='10:42' ||
             $horariosreunion->dia=='10:43' ||
             $horariosreunion->dia=='10:44' ||
             $horariosreunion->dia=='10:45' ||
             $horariosreunion->dia=='10:46' ||
             $horariosreunion->dia=='10:47' ||
             $horariosreunion->dia=='10:48' ||
             $horariosreunion->dia=='10:49' ||
             $horariosreunion->dia=='10:50' ||
             $horariosreunion->dia=='10:51' ||
             $horariosreunion->dia=='10:52' ||
             $horariosreunion->dia=='10:53' ||
             $horariosreunion->dia=='10:54' ||
             $horariosreunion->dia=='10:55' ||
             $horariosreunion->dia=='10:56' ||
             $horariosreunion->dia=='10:57' ||
             $horariosreunion->dia=='10:58' ||
             $horariosreunion->dia=='10:59' ||

             $horariosreunion->dia=='11:00' ||
             $horariosreunion->dia=='11:01' ||
             $horariosreunion->dia=='11:02' ||
             $horariosreunion->dia=='11:03' ||
             $horariosreunion->dia=='11:04' ||
             $horariosreunion->dia=='11:05' ||
             $horariosreunion->dia=='11:06' ||
             $horariosreunion->dia=='11:07' ||
             $horariosreunion->dia=='11:08' ||
             $horariosreunion->dia=='11:09' ||
             $horariosreunion->dia=='11:10' ||
             $horariosreunion->dia=='11:11' ||
             $horariosreunion->dia=='11:12' ||
             $horariosreunion->dia=='11:13' ||
             $horariosreunion->dia=='11:14' ||
             $horariosreunion->dia=='11:15' ||
             $horariosreunion->dia=='11:16' ||
             $horariosreunion->dia=='11:17' ||
             $horariosreunion->dia=='11:18' ||
             $horariosreunion->dia=='11:19' ||
             $horariosreunion->dia=='11:20' ||
             $horariosreunion->dia=='11:21' ||
             $horariosreunion->dia=='11:22' ||
             $horariosreunion->dia=='11:23' ||
             $horariosreunion->dia=='11:24' ||
             $horariosreunion->dia=='11:25' ||
             $horariosreunion->dia=='11:26' ||
             $horariosreunion->dia=='11:27' ||
             $horariosreunion->dia=='11:28' ||
             $horariosreunion->dia=='11:29' ||
             $horariosreunion->dia=='11:30' || 
             $horariosreunion->dia=='11:31' ||
             $horariosreunion->dia=='11:32' ||
             $horariosreunion->dia=='11:33' ||
             $horariosreunion->dia=='11:34' ||
             $horariosreunion->dia=='11:35' ||
             $horariosreunion->dia=='11:36' ||
             $horariosreunion->dia=='11:37' ||
             $horariosreunion->dia=='11:38' ||
             $horariosreunion->dia=='11:39' ||
             $horariosreunion->dia=='11:40' ||
             $horariosreunion->dia=='11:41' ||
             $horariosreunion->dia=='11:42' ||
             $horariosreunion->dia=='11:43' ||
             $horariosreunion->dia=='11:44' ||
             $horariosreunion->dia=='11:45' ||
             $horariosreunion->dia=='11:46' ||
             $horariosreunion->dia=='11:47' ||
             $horariosreunion->dia=='11:48' ||
             $horariosreunion->dia=='11:49' ||
             $horariosreunion->dia=='11:50' ||
             $horariosreunion->dia=='11:51' ||
             $horariosreunion->dia=='11:52' ||
             $horariosreunion->dia=='11:53' ||
             $horariosreunion->dia=='11:54' ||
             $horariosreunion->dia=='11:55' ||
             $horariosreunion->dia=='11:56' ||
             $horariosreunion->dia=='11:57' ||
             $horariosreunion->dia=='11:58' ||
             $horariosreunion->dia=='11:59' ||

             $horariosreunion->dia=='12:00' ||
             $horariosreunion->dia=='12:01' ||
             $horariosreunion->dia=='12:02' ||
             $horariosreunion->dia=='12:03' ||
             $horariosreunion->dia=='12:04' ||
             $horariosreunion->dia=='12:05' ||
             $horariosreunion->dia=='12:06' ||
             $horariosreunion->dia=='12:07' ||
             $horariosreunion->dia=='12:08' ||
             $horariosreunion->dia=='12:09' ||
             $horariosreunion->dia=='12:10' ||
             $horariosreunion->dia=='12:11' ||
             $horariosreunion->dia=='12:12' ||
             $horariosreunion->dia=='12:13' ||
             $horariosreunion->dia=='12:14' ||
             $horariosreunion->dia=='12:15' ||
             $horariosreunion->dia=='12:16' ||
             $horariosreunion->dia=='12:17' ||
             $horariosreunion->dia=='12:18' ||
             $horariosreunion->dia=='12:19' ||
             $horariosreunion->dia=='12:20' ||
             $horariosreunion->dia=='12:21' ||
             $horariosreunion->dia=='12:22' ||
             $horariosreunion->dia=='12:23' ||
             $horariosreunion->dia=='12:24' ||
             $horariosreunion->dia=='12:25' ||
             $horariosreunion->dia=='12:26' ||
             $horariosreunion->dia=='12:27' ||
             $horariosreunion->dia=='12:28' ||
             $horariosreunion->dia=='12:29' ||
             $horariosreunion->dia=='12:30' || 
             $horariosreunion->dia=='12:31' ||
             $horariosreunion->dia=='12:32' ||
             $horariosreunion->dia=='12:33' ||
             $horariosreunion->dia=='12:34' ||
             $horariosreunion->dia=='12:35' ||
             $horariosreunion->dia=='12:36' ||
             $horariosreunion->dia=='12:37' ||
             $horariosreunion->dia=='12:38' ||
             $horariosreunion->dia=='12:39' ||
             $horariosreunion->dia=='12:40' ||
             $horariosreunion->dia=='12:41' ||
             $horariosreunion->dia=='12:42' ||
             $horariosreunion->dia=='12:43' ||
             $horariosreunion->dia=='12:44' ||
             $horariosreunion->dia=='12:45' ||
             $horariosreunion->dia=='12:46' ||
             $horariosreunion->dia=='12:47' ||
             $horariosreunion->dia=='12:48' ||
             $horariosreunion->dia=='12:49' ||
             $horariosreunion->dia=='12:50' ||
             $horariosreunion->dia=='12:51' ||
             $horariosreunion->dia=='12:52' ||
             $horariosreunion->dia=='12:53' ||
             $horariosreunion->dia=='12:54' ||
             $horariosreunion->dia=='12:55' ||
             $horariosreunion->dia=='12:56' ||
             $horariosreunion->dia=='12:57' ||
             $horariosreunion->dia=='12:58' ||
             $horariosreunion->dia=='12:59'  )
              <td><span class="badge badge-primary">Mañana</span></td>
             @endif
             @if($horariosreunion->dia=='13:00' ||
             $horariosreunion->dia=='13:01' ||
             $horariosreunion->dia=='13:02' ||
             $horariosreunion->dia=='13:03' ||
             $horariosreunion->dia=='13:04' ||
             $horariosreunion->dia=='13:05' ||
             $horariosreunion->dia=='13:06' ||
             $horariosreunion->dia=='13:07' ||
             $horariosreunion->dia=='13:08' ||
             $horariosreunion->dia=='13:09' ||
             $horariosreunion->dia=='13:10' ||
             $horariosreunion->dia=='13:11' ||
             $horariosreunion->dia=='13:12' ||
             $horariosreunion->dia=='13:13' ||
             $horariosreunion->dia=='13:14' ||
             $horariosreunion->dia=='13:15' ||
             $horariosreunion->dia=='13:16' ||
             $horariosreunion->dia=='13:17' ||
             $horariosreunion->dia=='13:18' ||
             $horariosreunion->dia=='13:19' ||
             $horariosreunion->dia=='13:20' ||
             $horariosreunion->dia=='13:21' ||
             $horariosreunion->dia=='13:22' ||
             $horariosreunion->dia=='13:23' ||
             $horariosreunion->dia=='13:24' ||
             $horariosreunion->dia=='13:25' ||
             $horariosreunion->dia=='13:26' ||
             $horariosreunion->dia=='13:27' ||
             $horariosreunion->dia=='13:28' ||
             $horariosreunion->dia=='13:29' ||
             $horariosreunion->dia=='13:30' || 
             $horariosreunion->dia=='13:31' ||
             $horariosreunion->dia=='13:32' ||
             $horariosreunion->dia=='13:33' ||
             $horariosreunion->dia=='13:34' ||
             $horariosreunion->dia=='13:35' ||
             $horariosreunion->dia=='13:36' ||
             $horariosreunion->dia=='13:37' ||
             $horariosreunion->dia=='13:38' ||
             $horariosreunion->dia=='13:39' ||
             $horariosreunion->dia=='13:40' ||
             $horariosreunion->dia=='13:41' ||
             $horariosreunion->dia=='13:42' ||
             $horariosreunion->dia=='13:43' ||
             $horariosreunion->dia=='13:44' ||
             $horariosreunion->dia=='13:45' ||
             $horariosreunion->dia=='13:46' ||
             $horariosreunion->dia=='13:47' ||
             $horariosreunion->dia=='13:48' ||
             $horariosreunion->dia=='13:49' ||
             $horariosreunion->dia=='13:50' ||
             $horariosreunion->dia=='13:51' ||
             $horariosreunion->dia=='13:52' ||
             $horariosreunion->dia=='13:53' ||
             $horariosreunion->dia=='13:54' ||
             $horariosreunion->dia=='13:55' ||
             $horariosreunion->dia=='13:56' ||
             $horariosreunion->dia=='13:57' ||
             $horariosreunion->dia=='13:58' ||
             $horariosreunion->dia=='13:59' ||

             $horariosreunion->dia=='14:00' ||
             $horariosreunion->dia=='14:01' ||
             $horariosreunion->dia=='14:02' ||
             $horariosreunion->dia=='14:03' ||
             $horariosreunion->dia=='14:04' ||
             $horariosreunion->dia=='14:05' ||
             $horariosreunion->dia=='14:06' ||
             $horariosreunion->dia=='14:07' ||
             $horariosreunion->dia=='14:08' ||
             $horariosreunion->dia=='14:09' ||
             $horariosreunion->dia=='14:10' ||
             $horariosreunion->dia=='14:11' ||
             $horariosreunion->dia=='14:12' ||
             $horariosreunion->dia=='14:13' ||
             $horariosreunion->dia=='14:14' ||
             $horariosreunion->dia=='14:15' ||
             $horariosreunion->dia=='14:16' ||
             $horariosreunion->dia=='14:17' ||
             $horariosreunion->dia=='14:18' ||
             $horariosreunion->dia=='14:19' ||
             $horariosreunion->dia=='14:20' ||
             $horariosreunion->dia=='14:21' ||
             $horariosreunion->dia=='14:22' ||
             $horariosreunion->dia=='14:23' ||
             $horariosreunion->dia=='14:24' ||
             $horariosreunion->dia=='14:25' ||
             $horariosreunion->dia=='14:26' ||
             $horariosreunion->dia=='14:27' ||
             $horariosreunion->dia=='14:28' ||
             $horariosreunion->dia=='14:29' ||
             $horariosreunion->dia=='14:30' || 
             $horariosreunion->dia=='14:31' ||
             $horariosreunion->dia=='14:32' ||
             $horariosreunion->dia=='14:33' ||
             $horariosreunion->dia=='14:34' ||
             $horariosreunion->dia=='14:35' ||
             $horariosreunion->dia=='14:36' ||
             $horariosreunion->dia=='14:37' ||
             $horariosreunion->dia=='14:38' ||
             $horariosreunion->dia=='14:39' ||
             $horariosreunion->dia=='14:40' ||
             $horariosreunion->dia=='14:41' ||
             $horariosreunion->dia=='14:42' ||
             $horariosreunion->dia=='14:43' ||
             $horariosreunion->dia=='14:44' ||
             $horariosreunion->dia=='14:45' ||
             $horariosreunion->dia=='14:46' ||
             $horariosreunion->dia=='14:47' ||
             $horariosreunion->dia=='14:48' ||
             $horariosreunion->dia=='14:49' ||
             $horariosreunion->dia=='14:50' ||
             $horariosreunion->dia=='14:51' ||
             $horariosreunion->dia=='14:52' ||
             $horariosreunion->dia=='14:53' ||
             $horariosreunion->dia=='14:54' ||
             $horariosreunion->dia=='14:55' ||
             $horariosreunion->dia=='14:56' ||
             $horariosreunion->dia=='14:57' ||
             $horariosreunion->dia=='14:58' ||
             $horariosreunion->dia=='14:59' ||

             $horariosreunion->dia=='15:00' ||
             $horariosreunion->dia=='15:01' ||
             $horariosreunion->dia=='15:02' ||
             $horariosreunion->dia=='15:03' ||
             $horariosreunion->dia=='15:04' ||
             $horariosreunion->dia=='15:05' ||
             $horariosreunion->dia=='15:06' ||
             $horariosreunion->dia=='15:07' ||
             $horariosreunion->dia=='15:08' ||
             $horariosreunion->dia=='15:09' ||
             $horariosreunion->dia=='15:10' ||
             $horariosreunion->dia=='15:11' ||
             $horariosreunion->dia=='15:12' ||
             $horariosreunion->dia=='15:13' ||
             $horariosreunion->dia=='15:14' ||
             $horariosreunion->dia=='15:15' ||
             $horariosreunion->dia=='15:16' ||
             $horariosreunion->dia=='15:17' ||
             $horariosreunion->dia=='15:18' ||
             $horariosreunion->dia=='15:19' ||
             $horariosreunion->dia=='15:20' ||
             $horariosreunion->dia=='15:21' ||
             $horariosreunion->dia=='15:22' ||
             $horariosreunion->dia=='15:23' ||
             $horariosreunion->dia=='15:24' ||
             $horariosreunion->dia=='15:25' ||
             $horariosreunion->dia=='15:26' ||
             $horariosreunion->dia=='15:27' ||
             $horariosreunion->dia=='15:28' ||
             $horariosreunion->dia=='15:29' ||
             $horariosreunion->dia=='15:30' || 
             $horariosreunion->dia=='15:31' ||
             $horariosreunion->dia=='15:32' ||
             $horariosreunion->dia=='15:33' ||
             $horariosreunion->dia=='15:34' ||
             $horariosreunion->dia=='15:35' ||
             $horariosreunion->dia=='15:36' ||
             $horariosreunion->dia=='15:37' ||
             $horariosreunion->dia=='15:38' ||
             $horariosreunion->dia=='15:39' ||
             $horariosreunion->dia=='15:40' ||
             $horariosreunion->dia=='15:41' ||
             $horariosreunion->dia=='15:42' ||
             $horariosreunion->dia=='15:43' ||
             $horariosreunion->dia=='15:44' ||
             $horariosreunion->dia=='15:45' ||
             $horariosreunion->dia=='15:46' ||
             $horariosreunion->dia=='15:47' ||
             $horariosreunion->dia=='15:48' ||
             $horariosreunion->dia=='15:49' ||
             $horariosreunion->dia=='15:50' ||
             $horariosreunion->dia=='15:51' ||
             $horariosreunion->dia=='15:52' ||
             $horariosreunion->dia=='15:53' ||
             $horariosreunion->dia=='15:54' ||
             $horariosreunion->dia=='15:55' ||
             $horariosreunion->dia=='15:56' ||
             $horariosreunion->dia=='15:57' ||
             $horariosreunion->dia=='15:58' ||
             $horariosreunion->dia=='15:59' ||

             $horariosreunion->dia=='16:00' ||
             $horariosreunion->dia=='16:01' ||
             $horariosreunion->dia=='16:02' ||
             $horariosreunion->dia=='16:03' ||
             $horariosreunion->dia=='16:04' ||
             $horariosreunion->dia=='16:05' ||
             $horariosreunion->dia=='16:06' ||
             $horariosreunion->dia=='16:07' ||
             $horariosreunion->dia=='16:08' ||
             $horariosreunion->dia=='16:09' ||
             $horariosreunion->dia=='16:10' ||
             $horariosreunion->dia=='16:11' ||
             $horariosreunion->dia=='16:12' ||
             $horariosreunion->dia=='16:13' ||
             $horariosreunion->dia=='16:14' ||
             $horariosreunion->dia=='16:15' ||
             $horariosreunion->dia=='16:16' ||
             $horariosreunion->dia=='16:17' ||
             $horariosreunion->dia=='16:18' ||
             $horariosreunion->dia=='16:19' ||
             $horariosreunion->dia=='16:20' ||
             $horariosreunion->dia=='16:21' ||
             $horariosreunion->dia=='16:22' ||
             $horariosreunion->dia=='16:23' ||
             $horariosreunion->dia=='16:24' ||
             $horariosreunion->dia=='16:25' ||
             $horariosreunion->dia=='16:26' ||
             $horariosreunion->dia=='16:27' ||
             $horariosreunion->dia=='16:28' ||
             $horariosreunion->dia=='16:29' ||
             $horariosreunion->dia=='16:30' || 
             $horariosreunion->dia=='16:31' ||
             $horariosreunion->dia=='16:32' ||
             $horariosreunion->dia=='16:33' ||
             $horariosreunion->dia=='16:34' ||
             $horariosreunion->dia=='16:35' ||
             $horariosreunion->dia=='16:36' ||
             $horariosreunion->dia=='16:37' ||
             $horariosreunion->dia=='16:38' ||
             $horariosreunion->dia=='16:39' ||
             $horariosreunion->dia=='16:40' ||
             $horariosreunion->dia=='16:41' ||
             $horariosreunion->dia=='16:42' ||
             $horariosreunion->dia=='16:43' ||
             $horariosreunion->dia=='16:44' ||
             $horariosreunion->dia=='16:45' ||
             $horariosreunion->dia=='16:46' ||
             $horariosreunion->dia=='16:47' ||
             $horariosreunion->dia=='16:48' ||
             $horariosreunion->dia=='16:49' ||
             $horariosreunion->dia=='16:50' ||
             $horariosreunion->dia=='16:51' ||
             $horariosreunion->dia=='16:52' ||
             $horariosreunion->dia=='16:53' ||
             $horariosreunion->dia=='16:54' ||
             $horariosreunion->dia=='16:55' ||
             $horariosreunion->dia=='16:56' ||
             $horariosreunion->dia=='16:57' ||
             $horariosreunion->dia=='16:58' ||
             $horariosreunion->dia=='16:59' ||

             $horariosreunion->dia=='17:00' ||
             $horariosreunion->dia=='17:01' ||
             $horariosreunion->dia=='17:02' ||
             $horariosreunion->dia=='17:03' ||
             $horariosreunion->dia=='17:04' ||
             $horariosreunion->dia=='17:05' ||
             $horariosreunion->dia=='17:06' ||
             $horariosreunion->dia=='17:07' ||
             $horariosreunion->dia=='17:08' ||
             $horariosreunion->dia=='17:09' ||
             $horariosreunion->dia=='17:10' ||
             $horariosreunion->dia=='17:11' ||
             $horariosreunion->dia=='17:12' ||
             $horariosreunion->dia=='17:13' ||
             $horariosreunion->dia=='17:14' ||
             $horariosreunion->dia=='17:15' ||
             $horariosreunion->dia=='17:16' ||
             $horariosreunion->dia=='17:17' ||
             $horariosreunion->dia=='17:18' ||
             $horariosreunion->dia=='17:19' ||
             $horariosreunion->dia=='17:20' ||
             $horariosreunion->dia=='17:21' ||
             $horariosreunion->dia=='17:22' ||
             $horariosreunion->dia=='17:23' ||
             $horariosreunion->dia=='17:24' ||
             $horariosreunion->dia=='17:25' ||
             $horariosreunion->dia=='17:26' ||
             $horariosreunion->dia=='17:27' ||
             $horariosreunion->dia=='17:28' ||
             $horariosreunion->dia=='17:29' ||
             $horariosreunion->dia=='17:30' || 
             $horariosreunion->dia=='17:31' ||
             $horariosreunion->dia=='17:32' ||
             $horariosreunion->dia=='17:33' ||
             $horariosreunion->dia=='17:34' ||
             $horariosreunion->dia=='17:35' ||
             $horariosreunion->dia=='17:36' ||
             $horariosreunion->dia=='17:37' ||
             $horariosreunion->dia=='17:38' ||
             $horariosreunion->dia=='17:39' ||
             $horariosreunion->dia=='17:40' ||
             $horariosreunion->dia=='17:41' ||
             $horariosreunion->dia=='17:42' ||
             $horariosreunion->dia=='17:43' ||
             $horariosreunion->dia=='17:44' ||
             $horariosreunion->dia=='17:45' ||
             $horariosreunion->dia=='17:46' ||
             $horariosreunion->dia=='17:47' ||
             $horariosreunion->dia=='17:48' ||
             $horariosreunion->dia=='17:49' ||
             $horariosreunion->dia=='17:50' ||
             $horariosreunion->dia=='17:51' ||
             $horariosreunion->dia=='17:52' ||
             $horariosreunion->dia=='17:53' ||
             $horariosreunion->dia=='17:54' ||
             $horariosreunion->dia=='17:55' ||
             $horariosreunion->dia=='17:56' ||
             $horariosreunion->dia=='17:57' ||
             $horariosreunion->dia=='17:58' ||
             $horariosreunion->dia=='17:59' ||

             $horariosreunion->dia=='18:00' ||
             $horariosreunion->dia=='18:01' ||
             $horariosreunion->dia=='18:02' ||
             $horariosreunion->dia=='18:03' ||
             $horariosreunion->dia=='18:04' ||
             $horariosreunion->dia=='18:05' ||
             $horariosreunion->dia=='18:06' ||
             $horariosreunion->dia=='18:07' ||
             $horariosreunion->dia=='18:08' ||
             $horariosreunion->dia=='18:09' ||
             $horariosreunion->dia=='18:10' ||
             $horariosreunion->dia=='18:11' ||
             $horariosreunion->dia=='18:12' ||
             $horariosreunion->dia=='18:13' ||
             $horariosreunion->dia=='18:14' ||
             $horariosreunion->dia=='18:15' ||
             $horariosreunion->dia=='18:16' ||
             $horariosreunion->dia=='18:17' ||
             $horariosreunion->dia=='18:18' ||
             $horariosreunion->dia=='18:19' ||
             $horariosreunion->dia=='18:20' ||
             $horariosreunion->dia=='18:21' ||
             $horariosreunion->dia=='18:22' ||
             $horariosreunion->dia=='18:23' ||
             $horariosreunion->dia=='18:24' ||
             $horariosreunion->dia=='18:25' ||
             $horariosreunion->dia=='18:26' ||
             $horariosreunion->dia=='18:27' ||
             $horariosreunion->dia=='18:28' ||
             $horariosreunion->dia=='18:29' ||
             $horariosreunion->dia=='18:30' || 
             $horariosreunion->dia=='18:31' ||
             $horariosreunion->dia=='18:32' ||
             $horariosreunion->dia=='18:33' ||
             $horariosreunion->dia=='18:34' ||
             $horariosreunion->dia=='18:35' ||
             $horariosreunion->dia=='18:36' ||
             $horariosreunion->dia=='18:37' ||
             $horariosreunion->dia=='18:38' ||
             $horariosreunion->dia=='18:39' ||
             $horariosreunion->dia=='18:40' ||
             $horariosreunion->dia=='18:41' ||
             $horariosreunion->dia=='18:42' ||
             $horariosreunion->dia=='18:43' ||
             $horariosreunion->dia=='18:44' ||
             $horariosreunion->dia=='18:45' ||
             $horariosreunion->dia=='18:46' ||
             $horariosreunion->dia=='18:47' ||
             $horariosreunion->dia=='18:48' ||
             $horariosreunion->dia=='18:49' ||
             $horariosreunion->dia=='18:50' ||
             $horariosreunion->dia=='18:51' ||
             $horariosreunion->dia=='18:52' ||
             $horariosreunion->dia=='18:53' ||
             $horariosreunion->dia=='18:54' ||
             $horariosreunion->dia=='18:55' ||
             $horariosreunion->dia=='18:56' ||
             $horariosreunion->dia=='18:57' ||
             $horariosreunion->dia=='18:58' ||
             $horariosreunion->dia=='18:59' )
              <td><span class="badge badge-warning">Tarde</span></td>
             @endif
             @if($horariosreunion->dia=='19:00' ||
             $horariosreunion->dia=='19:01' ||
             $horariosreunion->dia=='19:02' ||
             $horariosreunion->dia=='19:03' ||
             $horariosreunion->dia=='19:04' ||
             $horariosreunion->dia=='19:05' ||
             $horariosreunion->dia=='19:06' ||
             $horariosreunion->dia=='19:07' ||
             $horariosreunion->dia=='19:08' ||
             $horariosreunion->dia=='19:09' ||
             $horariosreunion->dia=='19:10' ||
             $horariosreunion->dia=='19:11' ||
             $horariosreunion->dia=='19:12' ||
             $horariosreunion->dia=='19:13' ||
             $horariosreunion->dia=='19:14' ||
             $horariosreunion->dia=='19:15' ||
             $horariosreunion->dia=='19:16' ||
             $horariosreunion->dia=='19:17' ||
             $horariosreunion->dia=='19:18' ||
             $horariosreunion->dia=='19:19' ||
             $horariosreunion->dia=='19:20' ||
             $horariosreunion->dia=='19:21' ||
             $horariosreunion->dia=='19:22' ||
             $horariosreunion->dia=='19:23' ||
             $horariosreunion->dia=='19:24' ||
             $horariosreunion->dia=='19:25' ||
             $horariosreunion->dia=='19:26' ||
             $horariosreunion->dia=='19:27' ||
             $horariosreunion->dia=='19:28' ||
             $horariosreunion->dia=='19:29' ||
             $horariosreunion->dia=='19:30' || 
             $horariosreunion->dia=='19:31' ||
             $horariosreunion->dia=='19:32' ||
             $horariosreunion->dia=='19:33' ||
             $horariosreunion->dia=='19:34' ||
             $horariosreunion->dia=='19:35' ||
             $horariosreunion->dia=='19:36' ||
             $horariosreunion->dia=='19:37' ||
             $horariosreunion->dia=='19:38' ||
             $horariosreunion->dia=='19:39' ||
             $horariosreunion->dia=='19:40' ||
             $horariosreunion->dia=='19:41' ||
             $horariosreunion->dia=='19:42' ||
             $horariosreunion->dia=='19:43' ||
             $horariosreunion->dia=='19:44' ||
             $horariosreunion->dia=='19:45' ||
             $horariosreunion->dia=='19:46' ||
             $horariosreunion->dia=='19:47' ||
             $horariosreunion->dia=='19:48' ||
             $horariosreunion->dia=='19:49' ||
             $horariosreunion->dia=='19:50' ||
             $horariosreunion->dia=='19:51' ||
             $horariosreunion->dia=='19:52' ||
             $horariosreunion->dia=='19:53' ||
             $horariosreunion->dia=='19:54' ||
             $horariosreunion->dia=='19:55' ||
             $horariosreunion->dia=='19:56' ||
             $horariosreunion->dia=='19:57' ||
             $horariosreunion->dia=='19:58' ||
             $horariosreunion->dia=='19:59' ||  

             $horariosreunion->dia=='20:00' ||
             $horariosreunion->dia=='20:01' ||
             $horariosreunion->dia=='20:02' ||
             $horariosreunion->dia=='20:03' ||
             $horariosreunion->dia=='20:04' ||
             $horariosreunion->dia=='20:05' ||
             $horariosreunion->dia=='20:06' ||
             $horariosreunion->dia=='20:07' ||
             $horariosreunion->dia=='20:08' ||
             $horariosreunion->dia=='20:09' ||
             $horariosreunion->dia=='20:10' ||
             $horariosreunion->dia=='20:11' ||
             $horariosreunion->dia=='20:12' ||
             $horariosreunion->dia=='20:13' ||
             $horariosreunion->dia=='20:14' ||
             $horariosreunion->dia=='20:15' ||
             $horariosreunion->dia=='20:16' ||
             $horariosreunion->dia=='20:17' ||
             $horariosreunion->dia=='20:18' ||
             $horariosreunion->dia=='20:19' ||
             $horariosreunion->dia=='20:20' ||
             $horariosreunion->dia=='20:21' ||
             $horariosreunion->dia=='20:22' ||
             $horariosreunion->dia=='20:23' ||
             $horariosreunion->dia=='20:24' ||
             $horariosreunion->dia=='20:25' ||
             $horariosreunion->dia=='20:26' ||
             $horariosreunion->dia=='20:27' ||
             $horariosreunion->dia=='20:28' ||
             $horariosreunion->dia=='20:29' ||
             $horariosreunion->dia=='20:30' || 
             $horariosreunion->dia=='20:31' ||
             $horariosreunion->dia=='20:32' ||
             $horariosreunion->dia=='20:33' ||
             $horariosreunion->dia=='20:34' ||
             $horariosreunion->dia=='20:35' ||
             $horariosreunion->dia=='20:36' ||
             $horariosreunion->dia=='20:37' ||
             $horariosreunion->dia=='20:38' ||
             $horariosreunion->dia=='20:39' ||
             $horariosreunion->dia=='20:40' ||
             $horariosreunion->dia=='20:41' ||
             $horariosreunion->dia=='20:42' ||
             $horariosreunion->dia=='20:43' ||
             $horariosreunion->dia=='20:44' ||
             $horariosreunion->dia=='20:45' ||
             $horariosreunion->dia=='20:46' ||
             $horariosreunion->dia=='20:47' ||
             $horariosreunion->dia=='20:48' ||
             $horariosreunion->dia=='20:49' ||
             $horariosreunion->dia=='20:50' ||
             $horariosreunion->dia=='20:51' ||
             $horariosreunion->dia=='20:52' ||
             $horariosreunion->dia=='20:53' ||
             $horariosreunion->dia=='20:54' ||
             $horariosreunion->dia=='20:55' ||
             $horariosreunion->dia=='20:56' ||
             $horariosreunion->dia=='20:57' ||
             $horariosreunion->dia=='20:58' ||
             $horariosreunion->dia=='20:59' ||

             $horariosreunion->dia=='21:00' ||
             $horariosreunion->dia=='21:01' ||
             $horariosreunion->dia=='21:02' ||
             $horariosreunion->dia=='21:03' ||
             $horariosreunion->dia=='21:04' ||
             $horariosreunion->dia=='21:05' ||
             $horariosreunion->dia=='21:06' ||
             $horariosreunion->dia=='21:07' ||
             $horariosreunion->dia=='21:08' ||
             $horariosreunion->dia=='21:09' ||
             $horariosreunion->dia=='21:10' ||
             $horariosreunion->dia=='21:11' ||
             $horariosreunion->dia=='21:12' ||
             $horariosreunion->dia=='21:13' ||
             $horariosreunion->dia=='21:14' ||
             $horariosreunion->dia=='21:15' ||
             $horariosreunion->dia=='21:16' ||
             $horariosreunion->dia=='21:17' ||
             $horariosreunion->dia=='21:18' ||
             $horariosreunion->dia=='21:19' ||
             $horariosreunion->dia=='21:20' ||
             $horariosreunion->dia=='21:21' ||
             $horariosreunion->dia=='21:22' ||
             $horariosreunion->dia=='21:23' ||
             $horariosreunion->dia=='21:24' ||
             $horariosreunion->dia=='21:25' ||
             $horariosreunion->dia=='21:26' ||
             $horariosreunion->dia=='21:27' ||
             $horariosreunion->dia=='21:28' ||
             $horariosreunion->dia=='21:29' ||
             $horariosreunion->dia=='21:30' || 
             $horariosreunion->dia=='21:31' ||
             $horariosreunion->dia=='21:32' ||
             $horariosreunion->dia=='21:33' ||
             $horariosreunion->dia=='21:34' ||
             $horariosreunion->dia=='21:35' ||
             $horariosreunion->dia=='21:36' ||
             $horariosreunion->dia=='21:37' ||
             $horariosreunion->dia=='21:38' ||
             $horariosreunion->dia=='21:39' ||
             $horariosreunion->dia=='21:40' ||
             $horariosreunion->dia=='21:41' ||
             $horariosreunion->dia=='21:42' ||
             $horariosreunion->dia=='21:43' ||
             $horariosreunion->dia=='21:44' ||
             $horariosreunion->dia=='21:45' ||
             $horariosreunion->dia=='21:46' ||
             $horariosreunion->dia=='21:47' ||
             $horariosreunion->dia=='21:48' ||
             $horariosreunion->dia=='21:49' ||
             $horariosreunion->dia=='21:50' ||
             $horariosreunion->dia=='21:51' ||
             $horariosreunion->dia=='21:52' ||
             $horariosreunion->dia=='21:53' ||
             $horariosreunion->dia=='21:54' ||
             $horariosreunion->dia=='21:55' ||
             $horariosreunion->dia=='21:56' ||
             $horariosreunion->dia=='21:57' ||
             $horariosreunion->dia=='21:58' ||
             $horariosreunion->dia=='21:59' ||

             $horariosreunion->dia=='22:00' ||
             $horariosreunion->dia=='22:01' ||
             $horariosreunion->dia=='22:02' ||
             $horariosreunion->dia=='22:03' ||
             $horariosreunion->dia=='22:04' ||
             $horariosreunion->dia=='22:05' ||
             $horariosreunion->dia=='22:06' ||
             $horariosreunion->dia=='22:07' ||
             $horariosreunion->dia=='22:08' ||
             $horariosreunion->dia=='22:09' ||
             $horariosreunion->dia=='22:10' ||
             $horariosreunion->dia=='22:11' ||
             $horariosreunion->dia=='22:12' ||
             $horariosreunion->dia=='22:13' ||
             $horariosreunion->dia=='22:14' ||
             $horariosreunion->dia=='22:15' ||
             $horariosreunion->dia=='22:16' ||
             $horariosreunion->dia=='22:17' ||
             $horariosreunion->dia=='22:18' ||
             $horariosreunion->dia=='22:19' ||
             $horariosreunion->dia=='22:20' ||
             $horariosreunion->dia=='22:21' ||
             $horariosreunion->dia=='22:22' ||
             $horariosreunion->dia=='22:23' ||
             $horariosreunion->dia=='22:24' ||
             $horariosreunion->dia=='22:25' ||
             $horariosreunion->dia=='22:26' ||
             $horariosreunion->dia=='22:27' ||
             $horariosreunion->dia=='22:28' ||
             $horariosreunion->dia=='22:29' ||
             $horariosreunion->dia=='22:30' || 
             $horariosreunion->dia=='22:31' ||
             $horariosreunion->dia=='22:32' ||
             $horariosreunion->dia=='22:33' ||
             $horariosreunion->dia=='22:34' ||
             $horariosreunion->dia=='22:35' ||
             $horariosreunion->dia=='22:36' ||
             $horariosreunion->dia=='22:37' ||
             $horariosreunion->dia=='22:38' ||
             $horariosreunion->dia=='22:39' ||
             $horariosreunion->dia=='22:40' ||
             $horariosreunion->dia=='22:41' ||
             $horariosreunion->dia=='22:42' ||
             $horariosreunion->dia=='22:43' ||
             $horariosreunion->dia=='22:44' ||
             $horariosreunion->dia=='22:45' ||
             $horariosreunion->dia=='22:46' ||
             $horariosreunion->dia=='22:47' ||
             $horariosreunion->dia=='22:48' ||
             $horariosreunion->dia=='22:49' ||
             $horariosreunion->dia=='22:50' ||
             $horariosreunion->dia=='22:51' ||
             $horariosreunion->dia=='22:52' ||
             $horariosreunion->dia=='22:53' ||
             $horariosreunion->dia=='22:54' ||
             $horariosreunion->dia=='22:55' ||
             $horariosreunion->dia=='22:56' ||
             $horariosreunion->dia=='22:57' ||
             $horariosreunion->dia=='22:58' ||
             $horariosreunion->dia=='22:59' ||

             $horariosreunion->dia=='23:00' ||
             $horariosreunion->dia=='23:01' ||
             $horariosreunion->dia=='23:02' ||
             $horariosreunion->dia=='23:03' ||
             $horariosreunion->dia=='23:04' ||
             $horariosreunion->dia=='23:05' ||
             $horariosreunion->dia=='23:06' ||
             $horariosreunion->dia=='23:07' ||
             $horariosreunion->dia=='23:08' ||
             $horariosreunion->dia=='23:09' ||
             $horariosreunion->dia=='23:10' ||
             $horariosreunion->dia=='23:11' ||
             $horariosreunion->dia=='23:12' ||
             $horariosreunion->dia=='23:13' ||
             $horariosreunion->dia=='23:14' ||
             $horariosreunion->dia=='23:15' ||
             $horariosreunion->dia=='23:16' ||
             $horariosreunion->dia=='23:17' ||
             $horariosreunion->dia=='23:18' ||
             $horariosreunion->dia=='23:19' ||
             $horariosreunion->dia=='23:20' ||
             $horariosreunion->dia=='23:21' ||
             $horariosreunion->dia=='23:22' ||
             $horariosreunion->dia=='23:23' ||
             $horariosreunion->dia=='23:24' ||
             $horariosreunion->dia=='23:25' ||
             $horariosreunion->dia=='23:26' ||
             $horariosreunion->dia=='23:27' ||
             $horariosreunion->dia=='23:28' ||
             $horariosreunion->dia=='23:29' ||
             $horariosreunion->dia=='23:30' || 
             $horariosreunion->dia=='23:31' ||
             $horariosreunion->dia=='23:32' ||
             $horariosreunion->dia=='23:33' ||
             $horariosreunion->dia=='23:34' ||
             $horariosreunion->dia=='23:35' ||
             $horariosreunion->dia=='23:36' ||
             $horariosreunion->dia=='23:37' ||
             $horariosreunion->dia=='23:38' ||
             $horariosreunion->dia=='23:39' ||
             $horariosreunion->dia=='23:40' ||
             $horariosreunion->dia=='23:41' ||
             $horariosreunion->dia=='23:42' ||
             $horariosreunion->dia=='23:43' ||
             $horariosreunion->dia=='23:44' ||
             $horariosreunion->dia=='23:45' ||
             $horariosreunion->dia=='23:46' ||
             $horariosreunion->dia=='23:47' ||
             $horariosreunion->dia=='23:48' ||
             $horariosreunion->dia=='23:49' ||
             $horariosreunion->dia=='23:50' ||
             $horariosreunion->dia=='23:51' ||
             $horariosreunion->dia=='23:52' ||
             $horariosreunion->dia=='23:53' ||
             $horariosreunion->dia=='23:54' ||
             $horariosreunion->dia=='23:55' ||
             $horariosreunion->dia=='23:56' ||
             $horariosreunion->dia=='23:57' ||
             $horariosreunion->dia=='23:58' ||
             $horariosreunion->dia=='23:59' ||
             $horariosreunion->dia=='00:00')
              <td><span class="badge badge-dark">Noche</span></td>
             @endif

             
        </tr>
        @endif
       @endforeach
    </tbody>

</table>
                                    </div>
                                </div>
                         <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                              </div> 
        </div>
      </div>
      
    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
  <h5>Property Admin </h5>
</footer>

<footer class="w3-container w3-theme-d5">
  <h4 class="w3-center">Visitanos en nuestras redes</h4>
<div class="w3-center">
  <br>
  <a href="https://www.instagram.com/property_admin/?hl=es-la" class="w3-button w3-circle w3-large w3-pink"><i class="fa fa-instagram"></i></a>
  <a href="https://www.facebook.com/Property-Admin-105068594316195" class="w3-button w3-circle w3-large w3-theme"><i class="fa fa-facebook"></i></a>  
  <a class="w3-button w3-circle w3-large w3-card-4"><i class="fa fa-plus"></i></a>
</div>
</footer>
 
<script>
// Accordion
function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
    x.previousElementSibling.className += " w3-theme-d1";
  } else { 
    x.className = x.className.replace("w3-show", "");
    x.previousElementSibling.className = 
    x.previousElementSibling.className.replace(" w3-theme-d1", "");
  }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>

</body>
@else 
</br>
</br>
</br>
</br>
<meta http-equiv="Refresh" content="2;url={{url('/tokenes')}}
" />
@endif
@else 
</br>
</br>
</br>
</br>
<meta http-equiv="Refresh" content="2;url={{url('/terminos')}}
" />
@endif
@endsection

