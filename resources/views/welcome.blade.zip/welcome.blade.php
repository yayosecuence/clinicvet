<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-light-blue.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
  /* Make the image fully responsive */
  .carousel-inner img {
      width: 100%;
      height: 100%;
  }
  </style>
    </head>
    <!-- Sidebar on click -->
    <body>

<!-- Header -->
<header class="w3-container w3-theme w3-padding" id="myHeader">
  <i onclick="w3_open()" class="fa fa-bars w3-xlarge w3-button w3-theme"></i> 
  <div class="w3-center">
     <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" style="width:100px;">     
  
  <h1 class="w3-xxxlarge w3-animate-bottom">PROPERTY ADMIN</h1>
    <div class="w3-padding-32">
      <a href="{{ route('login') }}"> <button class="w3-btn w3-xlarge w3-dark-grey w3-hover-pink"  style="font-weight:900;">Iniciar Sesión</button></a>
    </div>
  </div>
</header>

<div class="w3-row-padding w3-center w3-margin-top">
<h2>NUESTROS PRECIOS</h2>
<br>
<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <h3>Plata</h3><br>
   <i class="w3-padding-16"> <img src="https://www.mypropertyadmin.com/imagenes_property/plan_estandar.png"  class="w3-image" style="width:50%"></i>
  <br>
  <br>
   <button onclick="document.getElementById('id02').style.display='block'" class="w3-button w3-padding-large w3-cyan w3-hover-pink"><i class="fa fa-eye"></i> Detalle</button>     
  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <h3>Oro</h3><br>
   <i class="w3-padding-16"> <img src="https://www.mypropertyadmin.com/imagenes_property/plan_plus.jpg"  class="w3-image" style="width:50%"></i>
  <br>
  <br>
   <button onclick="document.getElementById('id03').style.display='block'" class="w3-button w3-padding-large w3-cyan w3-hover-pink"><i class="fa fa-eye"></i> Detalle</button>     
  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <h3>Diamante</h3><br>
   <i class="w3-padding-16"> <img src="https://www.mypropertyadmin.com/imagenes_property/3.png"  class="w3-image" style="width:50%"></i>
  <br>
  <br>
   <button onclick="document.getElementById('id04').style.display='block'" class="w3-button w3-padding-large w3-cyan w3-hover-pink"><i class="fa fa-eye"></i> Detalle</button>     
  </div>
</div>
</div>

<!-- Modal1 -->
<div id="id02" class="w3-modal">
  <div class="w3-modal-content w3-card-4 w3-animate-top">
    <header class="w3-container w3-cyan w3-display-container"> 
      <span onclick="document.getElementById('id02').style.display='none'" class="w3-button w3-cyan w3-display-topright w3-hover-cyan"><i class="fa fa-remove"></i></span>
      <h4>Estas son las opciones que tienes en nuestro plan Plata.</h4>
    </header>
    <div class="w3-container">
      <br>
      <p class="w3-leftbar w3-border-pink">&nbsp;Notificaciones a copropietarios y convocatorias a reuniones y asambleas.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Estado de pago de alícuotas y reportes mensual o general.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Detalle y monto de caja.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Control de incidencias y siniestros.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Modelos y formatos de escritos.</p>    
      <p class="w3-leftbar w3-border-pink">&nbsp;Acceso a leyes y normas reglamentarias básicas.</p>    
      <p class="w3-leftbar w3-border-pink">&nbsp;Disposición de actas de cada asamblea y reportes.</p>   
      <p class="w3-leftbar w3-border-pink">&nbsp;Horarios de servicios comunitarios (recolección de basura, limpieza de piscinas, mantenimientos de redes o líneas eléctricas programados, etc.)</p>   
      <p class="w3-leftbar w3-border-pink">&nbsp;Catálogo de servicios de reparación y soluciones de daños y desperfectos particulares.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Servicios informativos inmobiliarios.</p>    
    </div>
    <footer class="w3-container w3-theme-d2">
      <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" class="w3-grayscale-max" alt="" width="20">
    <img src="https://www.mypropertyadmin.com/imagenes_property/logo_skylar.png" class="w3-grayscale-max" alt="" width="35">
    </footer>
  </div>
</div>
<!-- Modal2 -->
<div id="id03" class="w3-modal">
  <div class="w3-modal-content w3-card-4 w3-animate-top">
    <header class="w3-container w3-cyan w3-display-container"> 
      <span onclick="document.getElementById('id03').style.display='none'" class="w3-button w3-cyan w3-display-topright w3-hover-cyan"><i class="fa fa-remove"></i></span>
      <h4>Estas son las opciones que tienes en nuestro plan Plata.</h4>
    </header>
    <div class="w3-container ">
      <br>
      <p class="w3-leftbar w3-border-pink">&nbsp;Servicio Plata.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Sistema de encuestas y elecciones.</p> 
      <p class="w3-leftbar w3-border-pink">&nbsp;Servicio de asistencia telefónica inmediata y personalizada.</p> 
      <p class="w3-leftbar w3-border-pink">&nbsp;Bienes Raíces (Intermediación).</p> 
      <p class="w3-leftbar w3-border-pink">&nbsp;Reglamento interno de copropietarios.</p> 
    </div>
    <footer class="w3-container w3-theme-d2">
    <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" class="w3-grayscale-max" alt="" width="20">
    <img src="https://www.mypropertyadmin.com/imagenes_property/logo_skylar.png" class="w3-grayscale-max" alt="" width="35">
    </footer>
  </div>
</div>

<!-- Modal3 -->
<div id="id04" class="w3-modal">
  <div class="w3-modal-content w3-card-4 w3-animate-top">
    <header class="w3-container w3-cyan w3-display-container"> 
      <span onclick="document.getElementById('id04').style.display='none'" class="w3-button w3-cyan w3-display-topright w3-hover-cyan"><i class="fa fa-remove"></i></span>
      <h4>Estas son las opciones que tienes en nuestro plan Diamante.</h4>
    </header>
    <div class="w3-container ">
      <br>
      <p class="w3-leftbar w3-border-pink">&nbsp;Servicio Oro.</p>
      <p class="w3-leftbar w3-border-pink">&nbsp;Administración personalizada total.</p> 
    </div>
    <footer class="w3-container w3-theme-d2">
    <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" class="w3-grayscale-max" alt="" width="20">
    <img src="https://www.mypropertyadmin.com/imagenes_property/logo_skylar.png" class="w3-grayscale-max" alt="" width="35">
    </footer>
  </div>
</div>


<br>
<!-- Features Section -->
<div class="w3-container w3-padding-64 w3-light-blue w3-center">
  <h1 class="w3-jumbo"><b>Caracteristicas</b></h1>
  <p>Todo lo que tu urbanizacion necesita.</p>


  <div class="w3-row" style="margin-top:64px">
    <div class="w3-col s3">
      <i class="fa fa-file-text-o  w3-text-orange w3-jumbo"></i>
      <p>Reglamento interno</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-window-maximize w3-text-red w3-jumbo"></i>
      <p>Informacion al dia</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-eye w3-text-yellow w3-jumbo"></i>
      <p>Facil de usar</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-shield w3-text-green w3-jumbo"></i>
      <p>Seguridad</p>
    </div>
  </div>

  <div class="w3-row" style="margin-top:64px">
    <div class="w3-col s3">
      <i class="fa fa-cogs  w3-text-white w3-jumbo"></i>
      <p>soporte 24x7</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-comments-o w3-text-blue w3-jumbo"></i>
      <p>conectivdad</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-bell-o w3-text-amber w3-jumbo"></i>
      <p>Notificaciones</p>
    </div>
    <div class="w3-col s3">
      <i class="fa fa-database  w3-text-black w3-jumbo"></i>
      <p>Respaldo de informacion</p>
    </div>
  </div>
  
</div>

<br>

<!-- Promo Section "Statistics" -->

<div class="w3-container w3-row w3-center w3-pale-red w3-padding-64">
  <div class="w3-quarter">
     <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" style="width:100px;">
    <br>Property Admin.
  </div>
  <div class="w3-quarter">
    <h3>Asesoría legal</h3>
    <br>El asesoramiento legal es la entrega de una opinión profesional o formal sobre el procedimiento de la ley en relación con una situación de hecho particular.
  </div>
  <div class="w3-quarter">
    <h3>Venta y Bienes Raices</h3>
    <br>Por medio de nuestra plataforma podras publicar la venta de tu hogar o encontrar casas a tu gusto.
   <div class="w3-padding-32">
      <a href="{{ route('login') }}"> <button class="w3-btn w3-large w3-cyan w3-hover-pink"  style="font-weight:500;">Ir</button></a>
    </div>
  </div>
  
  <div class="w3-quarter">
   <h3>Referencias</h3>
    <br>Aqui podras observar nuestro trabajo.
    <br>
    <br>
    <br>
    
    <div class="w3-padding-32">
      <a href="{{ route('login') }}"> <button class="w3-btn w3-large w3-cyan w3-hover-pink"  style="font-weight:500;">Ir</button></a>
    </div>
  </div>
  
 
</div>

<br>
<!-- Contact Container -->
<div class="w3-container w3-padding-64 w3-theme-l1" id="contact">
  <div class="w3-row">
    <div class="w3-col m5">
    <div class="w3-padding-16"><span class="w3-xlarge w3-border-pink w3-bottombar">Contáctenos</span></div>
      <h3>Dirección</h3>
      <p>Portoviejo, Av. Reales Tamarindo y Ramón Edulfo Cedeño.</p>
      <p><i class="fa fa-map-marker w3-text-pink w3-xlarge"></i>Manabí, EC</p>
      <p><i class="fa fa-phone w3-text-pink w3-xlarge"></i>  +593 996584227</p>
      <p><i class="fa fa-envelope-o w3-text-pink w3-xlarge"></i> myproperty593@gmail.com</p>
    </div>
  <div class="w3-col m7">
      <form class="w3-container w3-card-4 w3-padding-16 w3-white" action="{{url('/email')}}" method="POST" target="_blank">
     {{ csrf_field() }}
    <div class="w3-section">      
        <label>Su Nombre:</label>
        <input class="w3-input" type="text" name="name" required>
      </div>
      <div class="w3-section">      
        <label>Su Email:</label>
        <input class="w3-input" type="text" name="correo" required>
      </div>
      <div class="w3-section">      
        <label>Mensaje a enviar:</label>
        <input class="w3-input" type="text" name="msg" required>
      </div>
    <div class="form-group">
        <button type="submit" id='btn-contact' class="w3-button w3-right w3-theme-d2 w3-hover-pink">Enviar</button>
    </div>
      </form>
    </div>
  </div>
</div>


<!-- Image of location/map -->
<img src="https://www.mypropertyadmin.com/imagenes_property/imagen_property2.jpg" class="w3-image" style="width:100%;min-height:250px;max-height:450px;">

<!-- Footer -->
<footer class="w3-container w3-padding-32 w3-theme-d1 w3-center">
  <div  class="w3-center">
  <h4>Redes Sociales</h4>
  <a class="w3-button w3-large w3-pink w3-hover-cyan" href="https://www.facebook.com/Property-Admin-105068594316195/" title="Facebook"><i class="fa fa-facebook"></i></a>
  <!--<a class="w3-button w3-large w3-pink w3-hover-cyan" href="javascript:void(0)" title="Twitter"><i class="fa fa-twitter"></i></a>-->
  <a class="w3-button w3-large w3-pink w3-hover-cyan" href="www.mypropertyadmin.com" title="Google +"><i class="fa fa-google-plus"></i></a>
  <a class="w3-button w3-large w3-pink w3-hover-cyan" href="https://www.instagram.com/Property_Admin/" title="Google +"><i class="fa fa-instagram"></i></a>
  <br>
    <img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.png" class="w3-grayscale-max" alt="" width="20">
    <img src="https://www.mypropertyadmin.com/imagenes_property/logo_skylar.png" class="w3-grayscale-max" alt="" width="35">
  </div>
  

  <div style="position:relative;bottom:100px;z-index:1;" class="w3-tooltip w3-right">   
    <a class="w3-button w3-pink w3-hover-cyan" href="#"><span class="w3-xlarge">
    <i class="fa fa-chevron-circle-up"></i></span></a>
  </div>
  
</footer>

<script>
// Script for side navigation
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "300px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}

// Close side navigation
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>

    </body>
</html>

