<img src="https://www.mypropertyadmin.com/imagenes_property/Admin2.jpg" class="rounded-circle" alt="Cinque Terre" width="304" height="236"> 
<h2>Nombre: {{$name}}</h2>
<h2>Correo: {{$correo}}</h2>
<h2>Mensaje: {{$msg}}</h2>