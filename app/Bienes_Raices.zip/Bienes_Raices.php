<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bienes_Raices extends Model
{
    //
}
