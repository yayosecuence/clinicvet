<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Idencuesta extends Model
{
    //
}
