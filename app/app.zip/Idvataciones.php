<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Idvataciones extends Model
{
    //
}
