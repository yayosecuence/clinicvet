<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reglamentos extends Model
{
    //
}
