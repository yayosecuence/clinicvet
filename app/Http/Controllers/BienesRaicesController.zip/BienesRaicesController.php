<?php

namespace App\Http\Controllers;

use App\Bienes_Raices;
use Illuminate\Http\Request;
use App\carrousell;
use App\User;
use App\Urbanizaciones;
use Illuminate\Support\Facades\Storage;

class BienesRaicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datos['bienes_raices']=Bienes_Raices::paginate(10);
        $bienesra=Bienes_Raices::all('titulo_propiedad','Foto1','Foto2','Foto3','Foto4','Foto5','habitaciones','id','area_terreno','provincia','ciudad','descripcion','baños','parqueadero_garaje','telefono','precio');
        
    return view('bienes_raices.index',compact('datos','bienesra'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('bienes_raices.form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datosBienes=request()->except('_token');

        if($request->hasFile('Foto1')){         

            $datosBienes['Foto1']=$request->file('Foto1')->store('Img_bienes','public');
        }
        if($request->hasFile('Foto2')){         

            $datosBienes['Foto2']=$request->file('Foto2')->store('Img_bienes','public');
        }
        if($request->hasFile('Foto3')){         

            $datosBienes['Foto3']=$request->file('Foto3')->store('Img_bienes','public');
        }
        if($request->hasFile('Foto4')){         

            $datosBienes['Foto4']=$request->file('Foto4')->store('Img_bienes','public');
        }
        if($request->hasFile('Foto5')){         

            $datosBienes['Foto5']=$request->file('Foto5')->store('Img_bienes','public');
        }

        bienes_raices::insert($datosBienes);

        //return  response()->json($datosCarrousell);
        return redirect('bienes_raices')->with('Mensaje','Datos agregados con exito.');  
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

